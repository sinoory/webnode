/**
 *  Copyright APPEX, 2015, 
 *  <HFTS-CLIENT>
 *  <����>
 *
 *  @defgroup <configure>
 *  @ingroup  <hfts-client>
 *
 *  <�ļ�����>
 *
 *  @{
 */
#ifndef APX_HFTSC_H_20150210
#define APX_HFTSC_H_20150210


#include "../include/apx_list.h"
#include "../include/apx_type.h"




#endif
/** @} */
