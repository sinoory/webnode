/*
 ============================================================================
 Name        : apx_comm.h
 Author      : 
 Version     :
 Copyright   : Appex
 Description : 
 	Common data structure between the module
 ============================================================================
 */

#ifndef APX_COMMON_H_
#define APX_COMMON_H_















#endif

