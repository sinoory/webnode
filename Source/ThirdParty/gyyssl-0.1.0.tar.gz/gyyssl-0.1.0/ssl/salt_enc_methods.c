/* ssl/salt_enc_methods.c */

#include "ssl_locl.h"
#include <openssl/md5.h>


SSL3_ENC_METHOD SSLv3_enc_data = {
    .enc = ssl3_enc,
    .mac = n_ssl3_mac,
    .setup_key_block = ssl3_setup_key_block,
    .generate_master_secret = ssl3_generate_master_secret,
    .change_cipher_state = ssl3_change_cipher_state,
    .final_finish_mac = ssl3_final_finish_mac,
    .finish_mac_length = MD5_DIGEST_LENGTH + SHA_DIGEST_LENGTH,
    .cert_verify_mac = ssl3_cert_verify_mac,
    .client_finished_label = SSL3_MD_CLIENT_FINISHED_CONST,
    .client_finished_label_len = 4,
    .server_finished_label = SSL3_MD_SERVER_FINISHED_CONST,
    .server_finished_label_len = 4,
    .alert_value = ssl3_alert_code,
    .export_keying_material = (int (*)(SSL *, unsigned char *, size_t,
        const char *, size_t, const unsigned char *, size_t,
        int use_context))ssl_undefined_function,
    .enc_flags = 0,
};

SSL3_ENC_METHOD TLSv1_enc_data = {
    .enc = tls1_enc,
    .mac = tls1_mac,
    .setup_key_block = tls1_setup_key_block,
    .generate_master_secret = tls1_generate_master_secret,
    .change_cipher_state = tls1_change_cipher_state,
    .final_finish_mac = tls1_final_finish_mac,
    .finish_mac_length = TLS1_FINISH_MAC_LENGTH,
    .cert_verify_mac = tls1_cert_verify_mac,
    .client_finished_label = TLS_MD_CLIENT_FINISH_CONST,
    .client_finished_label_len = TLS_MD_CLIENT_FINISH_CONST_SIZE,
    .server_finished_label = TLS_MD_SERVER_FINISH_CONST,
    .server_finished_label_len = TLS_MD_SERVER_FINISH_CONST_SIZE,
    .alert_value = tls1_alert_code,
    .export_keying_material = tls1_export_keying_material,
    .enc_flags = 0,
};

SSL3_ENC_METHOD TLSv1_1_enc_data = {
    .enc = tls1_enc,
    .mac = tls1_mac,
    .setup_key_block = tls1_setup_key_block,
    .generate_master_secret = tls1_generate_master_secret,
    .change_cipher_state = tls1_change_cipher_state,
    .final_finish_mac = tls1_final_finish_mac,
    .finish_mac_length = TLS1_FINISH_MAC_LENGTH,
    .cert_verify_mac = tls1_cert_verify_mac,
    .client_finished_label = TLS_MD_CLIENT_FINISH_CONST,
    .client_finished_label_len = TLS_MD_CLIENT_FINISH_CONST_SIZE,
    .server_finished_label = TLS_MD_SERVER_FINISH_CONST,
    .server_finished_label_len = TLS_MD_SERVER_FINISH_CONST_SIZE,
    .alert_value = tls1_alert_code,
    .export_keying_material = tls1_export_keying_material,
    .enc_flags = SSL_ENC_FLAG_EXPLICIT_IV,
};

SSL3_ENC_METHOD TLSv1_2_enc_data = {
    .enc = tls1_enc,
    .mac = tls1_mac,
    .setup_key_block = tls1_setup_key_block,
    .generate_master_secret = tls1_generate_master_secret,
    .change_cipher_state = tls1_change_cipher_state,
    .final_finish_mac = tls1_final_finish_mac,
    .finish_mac_length = TLS1_FINISH_MAC_LENGTH,
    .cert_verify_mac = tls1_cert_verify_mac,
    .client_finished_label = TLS_MD_CLIENT_FINISH_CONST,
    .client_finished_label_len = TLS_MD_CLIENT_FINISH_CONST_SIZE,
    .server_finished_label = TLS_MD_SERVER_FINISH_CONST,
    .server_finished_label_len = TLS_MD_SERVER_FINISH_CONST_SIZE,
    .alert_value = tls1_alert_code,
    .export_keying_material = tls1_export_keying_material,
    .enc_flags = SSL_ENC_FLAG_EXPLICIT_IV|SSL_ENC_FLAG_SIGALGS|
        SSL_ENC_FLAG_SHA256_PRF|SSL_ENC_FLAG_TLS1_2_CIPHERS,
};
