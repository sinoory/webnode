/* ssl/salt_cryptor.c */

#include <stdio.h>

#include "ssl_locl.h"

#include <openssl/evp.h>
#include <openssl/md5.h>


static unsigned char ssl3_pad_1[48] = {
    0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36,
    0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36,
    0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36,
    0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36,
    0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36,
    0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36
};

static unsigned char ssl3_pad_2[48] = {
    0x5c, 0x5c, 0x5c, 0x5c, 0x5c, 0x5c, 0x5c, 0x5c,
    0x5c, 0x5c, 0x5c, 0x5c, 0x5c, 0x5c, 0x5c, 0x5c,
    0x5c, 0x5c, 0x5c, 0x5c, 0x5c, 0x5c, 0x5c, 0x5c,
    0x5c, 0x5c, 0x5c, 0x5c, 0x5c, 0x5c, 0x5c, 0x5c,
    0x5c, 0x5c, 0x5c, 0x5c, 0x5c, 0x5c, 0x5c, 0x5c,
    0x5c, 0x5c, 0x5c, 0x5c, 0x5c, 0x5c, 0x5c, 0x5c
};

static int ssl3_handshake_mac(SSL *s, int md_nid, const char *sender,
    int len, unsigned char *p);

static int
ssl3_generate_key_block(SSL *s, unsigned char *km, int num)
{
    EVP_MD_CTX m5;
    EVP_MD_CTX s1;
    unsigned char buf[16], smd[SHA_DIGEST_LENGTH];
    unsigned char c = 'A';
    unsigned int i, j, k;

    k = 0;
    EVP_MD_CTX_init(&m5);
    EVP_MD_CTX_init(&s1);
    for (i = 0; (int)i < num; i += MD5_DIGEST_LENGTH) {
        k++;
        if (k > sizeof buf) {
            /* bug: 'buf' is too small for this ciphersuite */
            SSLerr(SSL_F_SSL3_GENERATE_KEY_BLOCK,
                ERR_R_INTERNAL_ERROR);
            return 0;
        }

        for (j = 0; j < k; j++)
            buf[j] = c;
        c++;
        if (!EVP_DigestInit_ex(&s1, EVP_sha1(), NULL))
            return 0;
        EVP_DigestUpdate(&s1, buf, k);
        EVP_DigestUpdate(&s1, s->session->master_key,
            s->session->master_key_length);
        EVP_DigestUpdate(&s1, s->s3->server_random, SSL3_RANDOM_SIZE);
        EVP_DigestUpdate(&s1, s->s3->client_random, SSL3_RANDOM_SIZE);
        EVP_DigestFinal_ex(&s1, smd, NULL);

        if (!EVP_DigestInit_ex(&m5, EVP_md5(), NULL))
            return 0;
        EVP_DigestUpdate(&m5, s->session->master_key,
            s->session->master_key_length);
        EVP_DigestUpdate(&m5, smd, SHA_DIGEST_LENGTH);
        if ((int)(i + MD5_DIGEST_LENGTH) > num) {
            EVP_DigestFinal_ex(&m5, smd, NULL);
            memcpy(km, smd, (num - i));
        } else
            EVP_DigestFinal_ex(&m5, km, NULL);

        km += MD5_DIGEST_LENGTH;
    }
    OPENSSL_cleanse(smd, SHA_DIGEST_LENGTH);
    EVP_MD_CTX_cleanup(&m5);
    EVP_MD_CTX_cleanup(&s1);
    return 1;
}

int
ssl3_change_cipher_state(SSL *s, int which)
{
    const unsigned char *client_write_mac_secret, *server_write_mac_secret;
    const unsigned char *client_write_key, *server_write_key;
    const unsigned char *client_write_iv, *server_write_iv;
    const unsigned char *mac_secret, *key, *iv;
    unsigned char *key_block;
    int mac_len, key_len, iv_len;
    char is_read, use_client_keys;
    EVP_CIPHER_CTX *cipher_ctx;
    const EVP_CIPHER *cipher;
    const EVP_MD *mac;


    cipher = s->s3->tmp.new_sym_enc;
    mac = s->s3->tmp.new_hash;

    /* mac == NULL will lead to a crash later */
    OPENSSL_assert(mac);

    /*
     * is_read is true if we have just read a ChangeCipherSpec message,
     * that is we need to update the read cipherspec. Otherwise we have
     * just written one.
     */
    is_read = (which & SSL3_CC_READ) != 0;

    /*
     * use_client_keys is true if we wish to use the keys for the "client
     * write" direction. This is the case if we're a client sending a
     * ChangeCipherSpec, or a server reading a client's ChangeCipherSpec.
     */
    use_client_keys = ((which == SSL3_CHANGE_CIPHER_CLIENT_WRITE) ||
        (which == SSL3_CHANGE_CIPHER_SERVER_READ));


    if (is_read) {
        EVP_CIPHER_CTX_free(s->enc_read_ctx);
        s->enc_read_ctx = NULL;
        if ((cipher_ctx = EVP_CIPHER_CTX_new()) == NULL)
            goto err;
        s->enc_read_ctx = cipher_ctx;

        if (ssl_replace_hash(&s->read_hash, mac) == NULL)
            goto err;
    } else {
        EVP_CIPHER_CTX_free(s->enc_write_ctx);
        s->enc_write_ctx = NULL;
        if ((cipher_ctx = EVP_CIPHER_CTX_new()) == NULL)
            goto err;
        s->enc_write_ctx = cipher_ctx;

        if (ssl_replace_hash(&s->write_hash, mac) == NULL)
            goto err;
    }

    memset(is_read ? s->s3->read_sequence : s->s3->write_sequence,
        0, SSL3_SEQUENCE_SIZE);

    mac_len = EVP_MD_size(mac);
    key_len = EVP_CIPHER_key_length(cipher);
    iv_len = EVP_CIPHER_iv_length(cipher);

    if (mac_len < 0)
        goto err2;

    key_block = s->s3->tmp.key_block;
    client_write_mac_secret = key_block;
    key_block += mac_len;
    server_write_mac_secret = key_block;
    key_block += mac_len;
    client_write_key = key_block;
    key_block += key_len;
    server_write_key = key_block;
    key_block += key_len;
    client_write_iv = key_block;
    key_block += iv_len;
    server_write_iv = key_block;
    key_block += iv_len;

    if (use_client_keys) {
        mac_secret = client_write_mac_secret;
        key = client_write_key;
        iv = client_write_iv;
    } else {
        mac_secret = server_write_mac_secret;
        key = server_write_key;
        iv = server_write_iv;
    }

    if (key_block - s->s3->tmp.key_block != s->s3->tmp.key_block_length) {
        SSLerr(SSL_F_SSL3_CHANGE_CIPHER_STATE, ERR_R_INTERNAL_ERROR);
        goto err2;
    }

    memcpy(is_read ? s->s3->read_mac_secret : s->s3->write_mac_secret,
        mac_secret, mac_len);

    EVP_CipherInit_ex(cipher_ctx, cipher, NULL, key, iv, !is_read);

    return (1);
err:
    SSLerr(SSL_F_SSL3_CHANGE_CIPHER_STATE, ERR_R_MALLOC_FAILURE);
err2:
    return (0);
}

int
ssl3_setup_key_block(SSL *s)
{
    int key_block_len, mac_len, key_len, iv_len;
    unsigned char *key_block;
    const EVP_CIPHER *cipher;
    const EVP_MD *mac;
    int ret = 0;

    if (s->s3->tmp.key_block_length != 0)
        return (1);

    if (!ssl_cipher_get_evp(s->session, &cipher, &mac, NULL, NULL)) {
        SSLerr(SSL_F_SSL3_SETUP_KEY_BLOCK,
            SSL_R_CIPHER_OR_HASH_UNAVAILABLE);
        return (0);
    }

    s->s3->tmp.new_sym_enc = cipher;
    s->s3->tmp.new_hash = mac;

    mac_len = EVP_MD_size(mac);
    key_len = EVP_CIPHER_key_length(cipher);
    iv_len = EVP_CIPHER_iv_length(cipher);

    if (mac_len < 0)
        return 0;

    ssl3_cleanup_key_block(s);

    if ((key_block = reallocarray(NULL, mac_len + key_len + iv_len, 2))
        == NULL)
        goto err;
    key_block_len = (mac_len + key_len + iv_len) * 2;

    s->s3->tmp.key_block_length = key_block_len;
    s->s3->tmp.key_block = key_block;

    ret = ssl3_generate_key_block(s, key_block, key_block_len);

    if (!(s->options & SSL_OP_DONT_INSERT_EMPTY_FRAGMENTS)) {
        /*
         * Enable vulnerability countermeasure for CBC ciphers with
         * known-IV problem (http://www.openssl.org/~bodo/tls-cbc.txt)
         */
        s->s3->need_empty_fragments = 1;

        if (s->session->cipher != NULL) {
            if (s->session->cipher->algorithm_enc == SSL_eNULL)
                s->s3->need_empty_fragments = 0;

        }
    }

    return ret;

err:
    SSLerr(SSL_F_SSL3_SETUP_KEY_BLOCK, ERR_R_MALLOC_FAILURE);
    return (0);
}

void
ssl3_cleanup_key_block(SSL *s)
{
    if (s->s3->tmp.key_block != NULL) {
        OPENSSL_cleanse(s->s3->tmp.key_block,
            s->s3->tmp.key_block_length);
        free(s->s3->tmp.key_block);
        s->s3->tmp.key_block = NULL;
    }
    s->s3->tmp.key_block_length = 0;
}

/* ssl3_enc encrypts/decrypts the record in |s->wrec| / |s->rrec|, respectively.
 *
 * Returns:
 *   0: (in non-constant time) if the record is publically invalid (i.e. too
 *       short etc).
 *   1: if the record's padding is valid / the encryption was successful.
 *   -1: if the record's padding is invalid or, if sending, an internal error
 *       occured.
 */
int
ssl3_enc(SSL *s, int send)
{
    SSL3_RECORD *rec;
    EVP_CIPHER_CTX *ds;
    unsigned long l;
    int bs, i, mac_size = 0;
    const EVP_CIPHER *enc;

    if (send) {
        ds = s->enc_write_ctx;
        rec = &(s->s3->wrec);
        if (s->enc_write_ctx == NULL)
            enc = NULL;
        else
            enc = EVP_CIPHER_CTX_cipher(s->enc_write_ctx);
    } else {
        ds = s->enc_read_ctx;
        rec = &(s->s3->rrec);
        if (s->enc_read_ctx == NULL)
            enc = NULL;
        else
            enc = EVP_CIPHER_CTX_cipher(s->enc_read_ctx);
    }

    if ((s->session == NULL) || (ds == NULL) || (enc == NULL)) {
        memmove(rec->data, rec->input, rec->length);
        rec->input = rec->data;
    } else {
        l = rec->length;
        bs = EVP_CIPHER_block_size(ds->cipher);

        /* COMPRESS */

        if ((bs != 1) && send) {
            i = bs - ((int)l % bs);

            /* we need to add 'i-1' padding bytes */
            l += i;
            /* the last of these zero bytes will be overwritten
             * with the padding length. */
            memset(&rec->input[rec->length], 0, i);
            rec->length += i;
            rec->input[l - 1] = (i - 1);
        }

        if (!send) {
            if (l == 0 || l % bs != 0)
                return 0;
            /* otherwise, rec->length >= bs */
        }

        EVP_Cipher(ds, rec->data, rec->input, l);

        if (EVP_MD_CTX_md(s->read_hash) != NULL)
            mac_size = EVP_MD_CTX_size(s->read_hash);
        if ((bs != 1) && !send)
            return ssl3_cbc_remove_padding(s, rec, bs, mac_size);
    }
    return (1);
}

int
ssl3_init_finished_mac(SSL *s)
{
    BIO_free(s->s3->handshake_buffer);
    ssl3_free_digest_list(s);

    s->s3->handshake_buffer = BIO_new(BIO_s_mem());
    if (s->s3->handshake_buffer == NULL)
        return (0);

    (void)BIO_set_close(s->s3->handshake_buffer, BIO_CLOSE);

    return (1);
}

void
ssl3_free_digest_list(SSL *s)
{
    int i;

    if (s->s3->handshake_dgst == NULL)
        return;
    for (i = 0; i < SSL_MAX_DIGEST; i++) {
        if (s->s3->handshake_dgst[i])
            EVP_MD_CTX_destroy(s->s3->handshake_dgst[i]);
    }
    free(s->s3->handshake_dgst);
    s->s3->handshake_dgst = NULL;
}

void
ssl3_finish_mac(SSL *s, const unsigned char *buf, int len)
{
    if (s->s3->handshake_buffer &&
        !(s->s3->flags & TLS1_FLAGS_KEEP_HANDSHAKE)) {
        BIO_write(s->s3->handshake_buffer, (void *)buf, len);
    } else {
        int i;
        for (i = 0; i < SSL_MAX_DIGEST; i++) {
            if (s->s3->handshake_dgst[i]!= NULL)
                EVP_DigestUpdate(s->s3->handshake_dgst[i], buf, len);
        }
    }
}

int
ssl3_digest_cached_records(SSL *s)
{
    int i;
    long mask;
    const EVP_MD *md;
    long hdatalen;
    void *hdata;

    ssl3_free_digest_list(s);

    s->s3->handshake_dgst = calloc(SSL_MAX_DIGEST, sizeof(EVP_MD_CTX *));
    if (s->s3->handshake_dgst == NULL) {
        SSLerr(SSL_F_SSL3_DIGEST_CACHED_RECORDS, ERR_R_MALLOC_FAILURE);
        return 0;
    }
    hdatalen = BIO_get_mem_data(s->s3->handshake_buffer, &hdata);
    if (hdatalen <= 0) {
        SSLerr(SSL_F_SSL3_DIGEST_CACHED_RECORDS,
            SSL_R_BAD_HANDSHAKE_LENGTH);
        return 0;
    }

    /* Loop through bits of the algorithm2 field and create MD contexts. */
    for (i = 0; ssl_get_handshake_digest(i, &mask, &md); i++) {
        if ((mask & ssl_get_algorithm2(s)) && md) {
            s->s3->handshake_dgst[i] = EVP_MD_CTX_create();
            if (s->s3->handshake_dgst[i] == NULL) {
                SSLerr(SSL_F_SSL3_DIGEST_CACHED_RECORDS,
                    ERR_R_MALLOC_FAILURE);
                return 0;
            }
            if (!EVP_DigestInit_ex(s->s3->handshake_dgst[i],
                md, NULL)) {
                EVP_MD_CTX_destroy(s->s3->handshake_dgst[i]);
                return 0;
            }
            if (!EVP_DigestUpdate(s->s3->handshake_dgst[i], hdata,
                hdatalen))
                return 0;
        }
    }

    if (!(s->s3->flags & TLS1_FLAGS_KEEP_HANDSHAKE)) {
        BIO_free(s->s3->handshake_buffer);
        s->s3->handshake_buffer = NULL;
    }

    return 1;
}

int
ssl3_cert_verify_mac(SSL *s, int md_nid, unsigned char *p)
{
    return (ssl3_handshake_mac(s, md_nid, NULL, 0, p));
}

int
ssl3_final_finish_mac(SSL *s, const char *sender, int len, unsigned char *p)
{
    int ret_md5, ret_sha1;

    ret_md5 = ssl3_handshake_mac(s, NID_md5, sender, len, p);
    if (ret_md5 == 0)
        return 0;
    p += ret_md5;
    ret_sha1 = ssl3_handshake_mac(s, NID_sha1, sender, len, p);
    if (ret_sha1 == 0)
        return 0;
    return (ret_md5 + ret_sha1);
}

static int
ssl3_handshake_mac(SSL *s, int md_nid, const char *sender, int len,
    unsigned char *p)
{
    unsigned int ret;
    int npad, n;
    unsigned int i;
    unsigned char md_buf[EVP_MAX_MD_SIZE];
    EVP_MD_CTX ctx, *d = NULL;

    if (s->s3->handshake_buffer)
        if (!ssl3_digest_cached_records(s))
            return 0;

    /* Search for digest of specified type in the handshake_dgst array. */
    for (i = 0; i < SSL_MAX_DIGEST; i++) {
        if (s->s3->handshake_dgst[i] &&
            EVP_MD_CTX_type(s->s3->handshake_dgst[i]) == md_nid) {
            d = s->s3->handshake_dgst[i];
            break;
        }
    }
    if (!d) {
        SSLerr(SSL_F_SSL3_HANDSHAKE_MAC, SSL_R_NO_REQUIRED_DIGEST);
        return 0;
    }
    EVP_MD_CTX_init(&ctx);
    if (!EVP_MD_CTX_copy_ex(&ctx, d))
        return 0;
    n = EVP_MD_CTX_size(&ctx);
    if (n < 0)
        return 0;

    npad = (48 / n) * n;
    if (sender != NULL)
        EVP_DigestUpdate(&ctx, sender, len);
    EVP_DigestUpdate(&ctx, s->session->master_key,
        s->session->master_key_length);
    EVP_DigestUpdate(&ctx, ssl3_pad_1, npad);
    EVP_DigestFinal_ex(&ctx, md_buf, &i);

    if (!EVP_DigestInit_ex(&ctx, EVP_MD_CTX_md(&ctx), NULL))
        return 0;
    EVP_DigestUpdate(&ctx, s->session->master_key,
        s->session->master_key_length);
    EVP_DigestUpdate(&ctx, ssl3_pad_2, npad);
    EVP_DigestUpdate(&ctx, md_buf, i);
    EVP_DigestFinal_ex(&ctx, p, &ret);

    EVP_MD_CTX_cleanup(&ctx);

    return ((int)ret);
}

int
n_ssl3_mac(SSL *ssl, unsigned char *md, int send)
{
    SSL3_RECORD *rec;
    unsigned char *mac_sec, *seq;
    EVP_MD_CTX md_ctx;
    const EVP_MD_CTX *hash;
    unsigned char *p, rec_char;
    size_t md_size, orig_len;
    int npad;
    int t;

    if (send) {
        rec = &(ssl->s3->wrec);
        mac_sec = &(ssl->s3->write_mac_secret[0]);
        seq = &(ssl->s3->write_sequence[0]);
        hash = ssl->write_hash;
    } else {
        rec = &(ssl->s3->rrec);
        mac_sec = &(ssl->s3->read_mac_secret[0]);
        seq = &(ssl->s3->read_sequence[0]);
        hash = ssl->read_hash;
    }

    t = EVP_MD_CTX_size(hash);
    if (t < 0)
        return -1;
    md_size = t;
    npad = (48 / md_size) * md_size;

    /* kludge: ssl3_cbc_remove_padding passes padding length in rec->type */
    orig_len = rec->length + md_size + ((unsigned int)rec->type >> 8);
    rec->type &= 0xff;

    if (!send &&
        EVP_CIPHER_CTX_mode(ssl->enc_read_ctx) == EVP_CIPH_CBC_MODE &&
        ssl3_cbc_record_digest_supported(hash)) {
        /* This is a CBC-encrypted record. We must avoid leaking any
         * timing-side channel information about how many blocks of
         * data we are hashing because that gives an attacker a
         * timing-oracle. */

        /* npad is, at most, 48 bytes and that's with MD5:
         *   16 + 48 + 8 (sequence bytes) + 1 + 2 = 75.
         *
         * With SHA-1 (the largest hash speced for SSLv3) the hash size
         * goes up 4, but npad goes down by 8, resulting in a smaller
         * total size. */
        unsigned char header[75];
        unsigned j = 0;
        memcpy(header + j, mac_sec, md_size);
        j += md_size;
        memcpy(header + j, ssl3_pad_1, npad);
        j += npad;
        memcpy(header + j, seq, 8);
        j += 8;
        header[j++] = rec->type;
        header[j++] = rec->length >> 8;
        header[j++] = rec->length & 0xff;

        if (!ssl3_cbc_digest_record(hash, md, &md_size, header,
            rec->input, rec->length + md_size, orig_len, mac_sec,
            md_size, 1 /* is SSLv3 */))
            return (-1);
    } else {
        unsigned int md_size_u;
        /* Chop the digest off the end :-) */
        EVP_MD_CTX_init(&md_ctx);

        if (!EVP_MD_CTX_copy_ex(&md_ctx, hash))
            return (-1);
        EVP_DigestUpdate(&md_ctx, mac_sec, md_size);
        EVP_DigestUpdate(&md_ctx, ssl3_pad_1, npad);
        EVP_DigestUpdate(&md_ctx, seq, 8);
        rec_char = rec->type;
        EVP_DigestUpdate(&md_ctx, &rec_char, 1);
        p = md;
        s2n(rec->length, p);
        EVP_DigestUpdate(&md_ctx, md, 2);
        EVP_DigestUpdate(&md_ctx, rec->input, rec->length);
        EVP_DigestFinal_ex(&md_ctx, md, NULL);

        if (!EVP_MD_CTX_copy_ex(&md_ctx, hash))
            return (-1);
        EVP_DigestUpdate(&md_ctx, mac_sec, md_size);
        EVP_DigestUpdate(&md_ctx, ssl3_pad_2, npad);
        EVP_DigestUpdate(&md_ctx, md, md_size);
        EVP_DigestFinal_ex(&md_ctx, md, &md_size_u);
        md_size = md_size_u;

        EVP_MD_CTX_cleanup(&md_ctx);
    }

    ssl3_record_sequence_increment(seq);

    return (md_size);
}

void
ssl3_record_sequence_increment(unsigned char *seq)
{
    int i;

    for (i = SSL3_SEQUENCE_SIZE - 1; i >= 0; i--) {
        if (++seq[i] != 0)
            break;
    }
}

int
ssl3_generate_master_secret(SSL *s, unsigned char *out, unsigned char *p,
    int len)
{
    static const unsigned char *salt[3] = { "A", "BB", "CCC", };
    unsigned char buf[EVP_MAX_MD_SIZE];
    EVP_MD_CTX ctx;
    int i, ret = 0;
    unsigned int n;

    EVP_MD_CTX_init(&ctx);
    for (i = 0; i < 3; i++) {
        if (!EVP_DigestInit_ex(&ctx, s->ctx->sha1, NULL))
            return 0;
        EVP_DigestUpdate(&ctx, salt[i], strlen((const char *)salt[i]));
        EVP_DigestUpdate(&ctx, p, len);
        EVP_DigestUpdate(&ctx, s->s3->client_random, SSL3_RANDOM_SIZE);
        EVP_DigestUpdate(&ctx, s->s3->server_random, SSL3_RANDOM_SIZE);
        EVP_DigestFinal_ex(&ctx, buf, &n);

        if (!EVP_DigestInit_ex(&ctx, s->ctx->md5, NULL))
            return 0;
        EVP_DigestUpdate(&ctx, p, len);
        EVP_DigestUpdate(&ctx, buf, n);
        EVP_DigestFinal_ex(&ctx, out, &n);
        out += n;
        ret += n;
    }
    EVP_MD_CTX_cleanup(&ctx);
    return (ret);
}



static int
tls1_P_hash(const EVP_MD *md, const unsigned char *sec, int sec_len,
    const void *seed1, int seed1_len, const void *seed2, int seed2_len,
    const void *seed3, int seed3_len, const void *seed4, int seed4_len,
    const void *seed5, int seed5_len, unsigned char *out, int olen)
{
    int chunk;
    size_t j;
    EVP_MD_CTX ctx, ctx_tmp;
    EVP_PKEY *mac_key;
    unsigned char A1[EVP_MAX_MD_SIZE];
    size_t A1_len;
    int ret = 0;

    chunk = EVP_MD_size(md);
    OPENSSL_assert(chunk >= 0);

    EVP_MD_CTX_init(&ctx);
    EVP_MD_CTX_init(&ctx_tmp);
    mac_key = EVP_PKEY_new_mac_key(EVP_PKEY_HMAC, NULL, sec, sec_len);
    if (!mac_key)
        goto err;
    if (!EVP_DigestSignInit(&ctx, NULL, md, NULL, mac_key))
        goto err;
    if (!EVP_DigestSignInit(&ctx_tmp, NULL, md, NULL, mac_key))
        goto err;
    if (seed1 && !EVP_DigestSignUpdate(&ctx, seed1, seed1_len))
        goto err;
    if (seed2 && !EVP_DigestSignUpdate(&ctx, seed2, seed2_len))
        goto err;
    if (seed3 && !EVP_DigestSignUpdate(&ctx, seed3, seed3_len))
        goto err;
    if (seed4 && !EVP_DigestSignUpdate(&ctx, seed4, seed4_len))
        goto err;
    if (seed5 && !EVP_DigestSignUpdate(&ctx, seed5, seed5_len))
        goto err;
    if (!EVP_DigestSignFinal(&ctx, A1, &A1_len))
        goto err;

    for (;;) {
        /* Reinit mac contexts */
        if (!EVP_DigestSignInit(&ctx, NULL, md, NULL, mac_key))
            goto err;
        if (!EVP_DigestSignInit(&ctx_tmp, NULL, md, NULL, mac_key))
            goto err;
        if (!EVP_DigestSignUpdate(&ctx, A1, A1_len))
            goto err;
        if (!EVP_DigestSignUpdate(&ctx_tmp, A1, A1_len))
            goto err;
        if (seed1 && !EVP_DigestSignUpdate(&ctx, seed1, seed1_len))
            goto err;
        if (seed2 && !EVP_DigestSignUpdate(&ctx, seed2, seed2_len))
            goto err;
        if (seed3 && !EVP_DigestSignUpdate(&ctx, seed3, seed3_len))
            goto err;
        if (seed4 && !EVP_DigestSignUpdate(&ctx, seed4, seed4_len))
            goto err;
        if (seed5 && !EVP_DigestSignUpdate(&ctx, seed5, seed5_len))
            goto err;

        if (olen > chunk) {
            if (!EVP_DigestSignFinal(&ctx, out, &j))
                goto err;
            out += j;
            olen -= j;
            /* calc the next A1 value */
            if (!EVP_DigestSignFinal(&ctx_tmp, A1, &A1_len))
                goto err;
        } else {
            /* last one */
            if (!EVP_DigestSignFinal(&ctx, A1, &A1_len))
                goto err;
            memcpy(out, A1, olen);
            break;
        }
    }
    ret = 1;

err:
    EVP_PKEY_free(mac_key);
    EVP_MD_CTX_cleanup(&ctx);
    EVP_MD_CTX_cleanup(&ctx_tmp);
    OPENSSL_cleanse(A1, sizeof(A1));
    return ret;
}

/* seed1 through seed5 are virtually concatenated */
static int
tls1_PRF(long digest_mask, const void *seed1, int seed1_len, const void *seed2,
    int seed2_len, const void *seed3, int seed3_len, const void *seed4,
    int seed4_len, const void *seed5, int seed5_len, const unsigned char *sec,
    int slen, unsigned char *out1, unsigned char *out2, int olen)
{
    int len, i, idx, count;
    const unsigned char *S1;
    long m;
    const EVP_MD *md;
    int ret = 0;

    /* Count number of digests and partition sec evenly */
    count = 0;
    for (idx = 0; ssl_get_handshake_digest(idx, &m, &md); idx++) {
        if ((m << TLS1_PRF_DGST_SHIFT) & digest_mask)
            count++;
    }
    if (count == 0) {
        SSLerr(SSL_F_TLS1_PRF,
            SSL_R_SSL_HANDSHAKE_FAILURE);
        goto err;
    }
    len = slen / count;
    if (count == 1)
        slen = 0;
    S1 = sec;
    memset(out1, 0, olen);
    for (idx = 0; ssl_get_handshake_digest(idx, &m, &md); idx++) {
        if ((m << TLS1_PRF_DGST_SHIFT) & digest_mask) {
            if (!md) {
                SSLerr(SSL_F_TLS1_PRF,
                    SSL_R_UNSUPPORTED_DIGEST_TYPE);
                goto err;
            }
            if (!tls1_P_hash(md , S1, len + (slen&1), seed1,
                seed1_len, seed2, seed2_len, seed3, seed3_len,
                seed4, seed4_len, seed5, seed5_len, out2, olen))
                goto err;
            S1 += len;
            for (i = 0; i < olen; i++) {
                out1[i] ^= out2[i];
            }
        }
    }
    ret = 1;

err:
    return ret;
}

static int
tls1_generate_key_block(SSL *s, unsigned char *km, unsigned char *tmp, int num)
{
    int ret;

    ret = tls1_PRF(ssl_get_algorithm2(s),
        TLS_MD_KEY_EXPANSION_CONST, TLS_MD_KEY_EXPANSION_CONST_SIZE,
        s->s3->server_random, SSL3_RANDOM_SIZE,
        s->s3->client_random, SSL3_RANDOM_SIZE,
        NULL, 0, NULL, 0,
        s->session->master_key, s->session->master_key_length,
        km, tmp, num);
    return ret;
}

/*
 * tls1_aead_ctx_init allocates aead_ctx, if needed. It returns 1 on success
 * and 0 on failure.
 */
static int
tls1_aead_ctx_init(SSL_AEAD_CTX **aead_ctx)
{
    if (*aead_ctx != NULL) {
        EVP_AEAD_CTX_cleanup(&(*aead_ctx)->ctx);
        return (1);
    }

    *aead_ctx = malloc(sizeof(SSL_AEAD_CTX));
    if (*aead_ctx == NULL) {
        SSLerr(SSL_F_TLS1_AEAD_CTX_INIT, ERR_R_MALLOC_FAILURE);
        return (0);
    }

    return (1);
}

static int
tls1_change_cipher_state_aead(SSL *s, char is_read, const unsigned char *key,
    unsigned key_len, const unsigned char *iv, unsigned iv_len)
{
    const EVP_AEAD *aead = s->s3->tmp.new_aead;
    SSL_AEAD_CTX *aead_ctx;

    if (is_read) {
        if (!tls1_aead_ctx_init(&s->aead_read_ctx))
            return 0;
        aead_ctx = s->aead_read_ctx;
    } else {
        if (!tls1_aead_ctx_init(&s->aead_write_ctx))
            return 0;
        aead_ctx = s->aead_write_ctx;
    }

    if (!EVP_AEAD_CTX_init(&aead_ctx->ctx, aead, key, key_len,
        EVP_AEAD_DEFAULT_TAG_LENGTH, NULL))
        return (0);
    if (iv_len > sizeof(aead_ctx->fixed_nonce)) {
        SSLerr(SSL_F_TLS1_CHANGE_CIPHER_STATE_AEAD,
            ERR_R_INTERNAL_ERROR);
        return (0);
    }
    memcpy(aead_ctx->fixed_nonce, iv, iv_len);
    aead_ctx->fixed_nonce_len = iv_len;
    aead_ctx->variable_nonce_len = 8;  /* always the case, currently. */
    aead_ctx->variable_nonce_in_record =
        (s->s3->tmp.new_cipher->algorithm2 &
        SSL_CIPHER_ALGORITHM2_VARIABLE_NONCE_IN_RECORD) != 0;
    if (aead_ctx->variable_nonce_len + aead_ctx->fixed_nonce_len !=
        EVP_AEAD_nonce_length(aead)) {
        SSLerr(SSL_F_TLS1_CHANGE_CIPHER_STATE_AEAD,
            ERR_R_INTERNAL_ERROR);
        return (0);
    }
    aead_ctx->tag_len = EVP_AEAD_max_overhead(aead);

    return (1);
}

/*
 * tls1_change_cipher_state_cipher performs the work needed to switch cipher
 * states when using EVP_CIPHER. The argument is_read is true iff this function
 * is being called due to reading, as opposed to writing, a ChangeCipherSpec
 * message. In order to support export ciphersuites, use_client_keys indicates
 * whether the key material provided is in the "client write" direction.
 */
static int
tls1_change_cipher_state_cipher(SSL *s, char is_read, char use_client_keys,
    const unsigned char *mac_secret, unsigned int mac_secret_size,
    const unsigned char *key, unsigned int key_len, const unsigned char *iv,
    unsigned int iv_len)
{
    EVP_CIPHER_CTX *cipher_ctx;
    const EVP_CIPHER *cipher;
    EVP_MD_CTX *mac_ctx;
    const EVP_MD *mac;
    int mac_type;

    cipher = s->s3->tmp.new_sym_enc;
    mac = s->s3->tmp.new_hash;
    mac_type = s->s3->tmp.new_mac_pkey_type;

    if (is_read) {
        if (s->s3->tmp.new_cipher->algorithm2 & TLS1_STREAM_MAC)
            s->mac_flags |= SSL_MAC_FLAG_READ_MAC_STREAM;
        else
            s->mac_flags &= ~SSL_MAC_FLAG_READ_MAC_STREAM;

        EVP_CIPHER_CTX_free(s->enc_read_ctx);
        s->enc_read_ctx = NULL;
        EVP_MD_CTX_destroy(s->read_hash);
        s->read_hash = NULL;

        if ((cipher_ctx = EVP_CIPHER_CTX_new()) == NULL)
            goto err;
        s->enc_read_ctx = cipher_ctx;
        if ((mac_ctx = EVP_MD_CTX_create()) == NULL)
            goto err;
        s->read_hash = mac_ctx;
    } else {
        if (s->s3->tmp.new_cipher->algorithm2 & TLS1_STREAM_MAC)
            s->mac_flags |= SSL_MAC_FLAG_WRITE_MAC_STREAM;
        else
            s->mac_flags &= ~SSL_MAC_FLAG_WRITE_MAC_STREAM;

        EVP_CIPHER_CTX_free(s->enc_write_ctx);
        s->enc_write_ctx = NULL;
        EVP_MD_CTX_destroy(s->write_hash);
        s->write_hash = NULL;

        if ((cipher_ctx = EVP_CIPHER_CTX_new()) == NULL)
            goto err;
        s->enc_write_ctx = cipher_ctx;
        if ((mac_ctx = EVP_MD_CTX_create()) == NULL)
            goto err;
        s->write_hash = mac_ctx;
    }

    if (EVP_CIPHER_mode(cipher) == EVP_CIPH_GCM_MODE) {
        EVP_CipherInit_ex(cipher_ctx, cipher, NULL, key, NULL,
            !is_read);
        EVP_CIPHER_CTX_ctrl(cipher_ctx, EVP_CTRL_GCM_SET_IV_FIXED,
            iv_len, (unsigned char *)iv);
    } else
        EVP_CipherInit_ex(cipher_ctx, cipher, NULL, key, iv, !is_read);

    if (!(EVP_CIPHER_flags(cipher) & EVP_CIPH_FLAG_AEAD_CIPHER)) {
        EVP_PKEY *mac_key = EVP_PKEY_new_mac_key(mac_type, NULL,
            mac_secret, mac_secret_size);
        if (mac_key == NULL)
            goto err;
        EVP_DigestSignInit(mac_ctx, NULL, mac, NULL, mac_key);
        EVP_PKEY_free(mac_key);
    } else if (mac_secret_size > 0) {
        /* Needed for "composite" AEADs, such as RC4-HMAC-MD5 */
        EVP_CIPHER_CTX_ctrl(cipher_ctx, EVP_CTRL_AEAD_SET_MAC_KEY,
            mac_secret_size, (unsigned char *)mac_secret);
    }

    if (s->s3->tmp.new_cipher->algorithm_enc == SSL_eGOST2814789CNT) {
        int nid;
        if (s->s3->tmp.new_cipher->algorithm2 & SSL_HANDSHAKE_MAC_GOST94)
            nid = NID_id_Gost28147_89_CryptoPro_A_ParamSet;
        else
            nid = NID_id_tc26_gost_28147_param_Z;

        EVP_CIPHER_CTX_ctrl(cipher_ctx, EVP_CTRL_GOST_SET_SBOX, nid, 0);
        if (s->s3->tmp.new_cipher->algorithm_mac == SSL_GOST89MAC)
            EVP_MD_CTX_ctrl(mac_ctx, EVP_MD_CTRL_GOST_SET_SBOX, nid, 0);
    }

    return (1);

err:
    SSLerr(SSL_F_TLS1_CHANGE_CIPHER_STATE_CIPHER, ERR_R_MALLOC_FAILURE);
    return (0);
}

int
tls1_change_cipher_state(SSL *s, int which)
{
    const unsigned char *client_write_mac_secret, *server_write_mac_secret;
    const unsigned char *client_write_key, *server_write_key;
    const unsigned char *client_write_iv, *server_write_iv;
    const unsigned char *mac_secret, *key, *iv;
    int mac_secret_size, key_len, iv_len;
    unsigned char *key_block, *seq;
    const EVP_CIPHER *cipher;
    const EVP_AEAD *aead;
    char is_read, use_client_keys;


    cipher = s->s3->tmp.new_sym_enc;
    aead = s->s3->tmp.new_aead;

    /*
     * is_read is true if we have just read a ChangeCipherSpec message,
     * that is we need to update the read cipherspec. Otherwise we have
     * just written one.
     */
    is_read = (which & SSL3_CC_READ) != 0;

    /*
     * use_client_keys is true if we wish to use the keys for the "client
     * write" direction. This is the case if we're a client sending a
     * ChangeCipherSpec, or a server reading a client's ChangeCipherSpec.
     */
    use_client_keys = ((which == SSL3_CHANGE_CIPHER_CLIENT_WRITE) ||
        (which == SSL3_CHANGE_CIPHER_SERVER_READ));


    /*
     * Reset sequence number to zero.
     */
    seq = is_read ? s->s3->read_sequence : s->s3->write_sequence;
    memset(seq, 0, SSL3_SEQUENCE_SIZE);

    if (aead != NULL) {
        key_len = EVP_AEAD_key_length(aead);
        iv_len = SSL_CIPHER_AEAD_FIXED_NONCE_LEN(s->s3->tmp.new_cipher);
    } else {
        key_len = EVP_CIPHER_key_length(cipher);
        iv_len = EVP_CIPHER_iv_length(cipher);

        /* If GCM mode only part of IV comes from PRF. */
        if (EVP_CIPHER_mode(cipher) == EVP_CIPH_GCM_MODE)
            iv_len = EVP_GCM_TLS_FIXED_IV_LEN;
    }

    mac_secret_size = s->s3->tmp.new_mac_secret_size;

    key_block = s->s3->tmp.key_block;
    client_write_mac_secret = key_block;
    key_block += mac_secret_size;
    server_write_mac_secret = key_block;
    key_block += mac_secret_size;
    client_write_key = key_block;
    key_block += key_len;
    server_write_key = key_block;
    key_block += key_len;
    client_write_iv = key_block;
    key_block += iv_len;
    server_write_iv = key_block;
    key_block += iv_len;

    if (use_client_keys) {
        mac_secret = client_write_mac_secret;
        key = client_write_key;
        iv = client_write_iv;
    } else {
        mac_secret = server_write_mac_secret;
        key = server_write_key;
        iv = server_write_iv;
    }

    if (key_block - s->s3->tmp.key_block != s->s3->tmp.key_block_length) {
        SSLerr(SSL_F_TLS1_CHANGE_CIPHER_STATE, ERR_R_INTERNAL_ERROR);
        goto err2;
    }

    if (is_read) {
        memcpy(s->s3->read_mac_secret, mac_secret, mac_secret_size);
        s->s3->read_mac_secret_size = mac_secret_size;
    } else {
        memcpy(s->s3->write_mac_secret, mac_secret, mac_secret_size);
        s->s3->write_mac_secret_size = mac_secret_size;
    }

    if (aead != NULL) {
        return tls1_change_cipher_state_aead(s, is_read, key, key_len,
            iv, iv_len);
    }

    return tls1_change_cipher_state_cipher(s, is_read, use_client_keys,
        mac_secret, mac_secret_size, key, key_len, iv, iv_len);

err2:
    return (0);
}

int
tls1_setup_key_block(SSL *s)
{
    unsigned char *key_block, *tmp_block = NULL;
    int mac_type = NID_undef, mac_secret_size = 0;
    int key_block_len, key_len, iv_len;
    const EVP_CIPHER *cipher = NULL;
    const EVP_AEAD *aead = NULL;
    const EVP_MD *mac = NULL;
    int ret = 0;

    if (s->s3->tmp.key_block_length != 0)
        return (1);

    if (s->session->cipher
            && (s->session->cipher->algorithm2 & SSL_CIPHER_ALGORITHM2_AEAD))
    {
        if (!ssl_cipher_get_evp_aead(s->session, &aead))
        {
            SSLerr(SSL_F_TLS1_SETUP_KEY_BLOCK,
                    SSL_R_CIPHER_OR_HASH_UNAVAILABLE);
            return (0);
        }
        key_len = EVP_AEAD_key_length(aead);
        iv_len = SSL_CIPHER_AEAD_FIXED_NONCE_LEN(s->session->cipher);
    }
    else
    {
        if (!ssl_cipher_get_evp(s->session, &cipher, &mac, &mac_type,
                &mac_secret_size))
        {
            SSLerr(SSL_F_TLS1_SETUP_KEY_BLOCK,
                    SSL_R_CIPHER_OR_HASH_UNAVAILABLE);
            return (0);
        }
        key_len = EVP_CIPHER_key_length(cipher);
        iv_len = EVP_CIPHER_iv_length(cipher);

        /* If GCM mode only part of IV comes from PRF. */
        if (EVP_CIPHER_mode(cipher) == EVP_CIPH_GCM_MODE)
            iv_len = EVP_GCM_TLS_FIXED_IV_LEN;
    }

    s->s3->tmp.new_aead = aead;
    s->s3->tmp.new_sym_enc = cipher;
    s->s3->tmp.new_hash = mac;
    s->s3->tmp.new_mac_pkey_type = mac_type;
    s->s3->tmp.new_mac_secret_size = mac_secret_size;

    ssl3_cleanup_key_block(s);

    if ((key_block = reallocarray(NULL, mac_secret_size + key_len + iv_len,
        2)) == NULL) {
        SSLerr(SSL_F_TLS1_SETUP_KEY_BLOCK, ERR_R_MALLOC_FAILURE);
        goto err;
    }
    key_block_len = (mac_secret_size + key_len + iv_len) * 2;

    s->s3->tmp.key_block_length = key_block_len;
    s->s3->tmp.key_block = key_block;

    if ((tmp_block = malloc(key_block_len)) == NULL) {
        SSLerr(SSL_F_TLS1_SETUP_KEY_BLOCK, ERR_R_MALLOC_FAILURE);
        goto err;
    }

    if (!tls1_generate_key_block(s, key_block, tmp_block, key_block_len))
        goto err;

    if (!(s->options & SSL_OP_DONT_INSERT_EMPTY_FRAGMENTS) &&
        s->method->version <= TLS1_VERSION) {
        /*
         * Enable vulnerability countermeasure for CBC ciphers with
         * known-IV problem (http://www.openssl.org/~bodo/tls-cbc.txt)
         */
        s->s3->need_empty_fragments = 1;

        if (s->session->cipher != NULL) {
            if (s->session->cipher->algorithm_enc == SSL_eNULL)
                s->s3->need_empty_fragments = 0;
        }
    }

    ret = 1;

err:
    if (tmp_block) {
        OPENSSL_cleanse(tmp_block, key_block_len);
        free(tmp_block);
    }
    return (ret);
}

/* tls1_enc encrypts/decrypts the record in |s->wrec| / |s->rrec|, respectively.
 *
 * Returns:
 *   0: (in non-constant time) if the record is publically invalid (i.e. too
 *       short etc).
 *   1: if the record's padding is valid / the encryption was successful.
 *   -1: if the record's padding/AEAD-authenticator is invalid or, if sending,
 *       an internal error occured.
 */
int
tls1_enc(SSL *s, int send)
{
    const SSL_AEAD_CTX *aead;
    const EVP_CIPHER *enc;
    EVP_CIPHER_CTX *ds;
    SSL3_RECORD *rec;
    unsigned char *seq;
    unsigned long l;
    int bs, i, j, k, pad = 0, ret, mac_size = 0;

    if (send) {
        aead = s->aead_write_ctx;
        rec = &s->s3->wrec;
        seq = s->s3->write_sequence;
    } else {
        aead = s->aead_read_ctx;
        rec = &s->s3->rrec;
        seq = s->s3->read_sequence;
    }

    if (aead) {
        unsigned char ad[13], *in, *out, nonce[16];
        unsigned nonce_used;
        ssize_t n;

        memcpy(ad, seq, SSL3_SEQUENCE_SIZE);
        ssl3_record_sequence_increment(seq);

        ad[8] = rec->type;
        ad[9] = (unsigned char)(s->version >> 8);
        ad[10] = (unsigned char)(s->version);

        if (aead->fixed_nonce_len +
            aead->variable_nonce_len > sizeof(nonce) ||
            aead->variable_nonce_len > 8)
            return -1;  /* internal error - should never happen. */

        memcpy(nonce, aead->fixed_nonce, aead->fixed_nonce_len);
        nonce_used = aead->fixed_nonce_len;

        if (send) {
            size_t len = rec->length;
            size_t eivlen = 0;
            in = rec->input;
            out = rec->data;

            /*
             * When sending we use the sequence number as the
             * variable part of the nonce.
             */
            if (aead->variable_nonce_len > 8)
                return -1;
            memcpy(nonce + nonce_used, ad,
                aead->variable_nonce_len);
            nonce_used += aead->variable_nonce_len;

            /*
             * In do_ssl3_write, rec->input is moved forward by
             * variable_nonce_len in order to leave space for the
             * variable nonce. Thus we can copy the sequence number
             * bytes into place without overwriting any of the
             * plaintext.
             */
            if (aead->variable_nonce_in_record) {
                memcpy(out, ad, aead->variable_nonce_len);
                len -= aead->variable_nonce_len;
                eivlen = aead->variable_nonce_len;
            }

            ad[11] = len >> 8;
            ad[12] = len & 0xff;

            if (!EVP_AEAD_CTX_seal(&aead->ctx,
                out + eivlen, &n, len + aead->tag_len, nonce,
                nonce_used, in + eivlen, len, ad, sizeof(ad)))
                return -1;
            if (n >= 0 && aead->variable_nonce_in_record)
                n += aead->variable_nonce_len;
        } else {
            /* receive */
            size_t len = rec->length;

            if (rec->data != rec->input)
                return -1;  /* internal error - should never happen. */
            out = in = rec->input;

            if (len < aead->variable_nonce_len)
                return 0;
            memcpy(nonce + nonce_used,
                aead->variable_nonce_in_record ? in : ad,
                aead->variable_nonce_len);
            nonce_used += aead->variable_nonce_len;

            if (aead->variable_nonce_in_record) {
                in += aead->variable_nonce_len;
                len -= aead->variable_nonce_len;
                out += aead->variable_nonce_len;
            }

            if (len < aead->tag_len)
                return 0;
            len -= aead->tag_len;

            ad[11] = len >> 8;
            ad[12] = len & 0xff;

            if (!EVP_AEAD_CTX_open(&aead->ctx, out, &n, len, nonce,
                nonce_used, in, len + aead->tag_len, ad,
                sizeof(ad)))
                return -1;

            rec->data = rec->input = out;
        }

        if (n == -1)
            return -1;
        rec->length = n;

        return 1;
    }

    if (send) {
        if (EVP_MD_CTX_md(s->write_hash)) {
            int n = EVP_MD_CTX_size(s->write_hash);
            OPENSSL_assert(n >= 0);
        }
        ds = s->enc_write_ctx;
        if (s->enc_write_ctx == NULL)
            enc = NULL;
        else {
            int ivlen = 0;
            enc = EVP_CIPHER_CTX_cipher(s->enc_write_ctx);
            if (SSL_USE_EXPLICIT_IV(s) &&
                EVP_CIPHER_mode(enc) == EVP_CIPH_CBC_MODE)
                ivlen = EVP_CIPHER_iv_length(enc);
            if (ivlen > 1) {
                if (rec->data != rec->input)
                    /* we can't write into the input stream:
                     * Can this ever happen?? (steve)
                     */
                    fprintf(stderr,
                        "%s:%d: rec->data != rec->input\n",
                        __FILE__, __LINE__);
                else
                    arc4random_buf(rec->input, ivlen);
            }
        }
    } else {
        if (EVP_MD_CTX_md(s->read_hash)) {
            int n = EVP_MD_CTX_size(s->read_hash);
            OPENSSL_assert(n >= 0);
        }
        ds = s->enc_read_ctx;
        if (s->enc_read_ctx == NULL)
            enc = NULL;
        else
            enc = EVP_CIPHER_CTX_cipher(s->enc_read_ctx);
    }

    if ((s->session == NULL) || (ds == NULL) || (enc == NULL)) {
        memmove(rec->data, rec->input, rec->length);
        rec->input = rec->data;
        ret = 1;
    } else {
        l = rec->length;
        bs = EVP_CIPHER_block_size(ds->cipher);

        if (EVP_CIPHER_flags(ds->cipher) & EVP_CIPH_FLAG_AEAD_CIPHER) {
            unsigned char buf[13];

            memcpy(buf, seq, SSL3_SEQUENCE_SIZE);
            ssl3_record_sequence_increment(seq);

            buf[8] = rec->type;
            buf[9] = (unsigned char)(s->version >> 8);
            buf[10] = (unsigned char)(s->version);
            buf[11] = rec->length >> 8;
            buf[12] = rec->length & 0xff;
            pad = EVP_CIPHER_CTX_ctrl(ds, EVP_CTRL_AEAD_TLS1_AAD, 13, buf);
            if (send) {
                l += pad;
                rec->length += pad;
            }
        } else if ((bs != 1) && send) {
            i = bs - ((int)l % bs);

            /* Add weird padding of upto 256 bytes */

            /* we need to add 'i' padding bytes of value j */
            j = i - 1;
            if (s->options & SSL_OP_TLS_BLOCK_PADDING_BUG) {
                if (s->s3->flags & TLS1_FLAGS_TLS_PADDING_BUG)
                    j++;
            }
            for (k = (int)l; k < (int)(l + i); k++)
                rec->input[k] = j;
            l += i;
            rec->length += i;
        }

        if (!send) {
            if (l == 0 || l % bs != 0)
                return 0;
        }

        i = EVP_Cipher(ds, rec->data, rec->input, l);
        if ((EVP_CIPHER_flags(ds->cipher) &
            EVP_CIPH_FLAG_CUSTOM_CIPHER) ? (i < 0) : (i == 0))
            return -1;  /* AEAD can fail to verify MAC */
        if (EVP_CIPHER_mode(enc) == EVP_CIPH_GCM_MODE && !send) {
            rec->data += EVP_GCM_TLS_EXPLICIT_IV_LEN;
            rec->input += EVP_GCM_TLS_EXPLICIT_IV_LEN;
            rec->length -= EVP_GCM_TLS_EXPLICIT_IV_LEN;
        }

        ret = 1;
        if (EVP_MD_CTX_md(s->read_hash) != NULL)
            mac_size = EVP_MD_CTX_size(s->read_hash);
        if ((bs != 1) && !send)
            ret = tls1_cbc_remove_padding(s, rec, bs, mac_size);
        if (pad && !send)
            rec->length -= pad;
    }
    return ret;
}

int
tls1_cert_verify_mac(SSL *s, int md_nid, unsigned char *out)
{
    EVP_MD_CTX ctx, *d = NULL;
    unsigned int ret;
    int i;

    if (s->s3->handshake_buffer)
        if (!ssl3_digest_cached_records(s))
            return 0;

    for (i = 0; i < SSL_MAX_DIGEST; i++) {
        if (s->s3->handshake_dgst[i] &&
            EVP_MD_CTX_type(s->s3->handshake_dgst[i]) == md_nid) {
            d = s->s3->handshake_dgst[i];
            break;
        }
    }
    if (d == NULL) {
        SSLerr(SSL_F_TLS1_CERT_VERIFY_MAC, SSL_R_NO_REQUIRED_DIGEST);
        return 0;
    }

    EVP_MD_CTX_init(&ctx);
    if (!EVP_MD_CTX_copy_ex(&ctx, d))
        return 0;
    EVP_DigestFinal_ex(&ctx, out, &ret);
    EVP_MD_CTX_cleanup(&ctx);

    return ((int)ret);
}

int
tls1_final_finish_mac(SSL *s, const char *str, int slen, unsigned char *out)
{
    unsigned int i;
    EVP_MD_CTX ctx;
    unsigned char buf[2*EVP_MAX_MD_SIZE];
    unsigned char *q, buf2[12];
    int idx;
    long mask;
    int err = 0;
    const EVP_MD *md;

    q = buf;

    if (s->s3->handshake_buffer)
        if (!ssl3_digest_cached_records(s))
            return 0;

    EVP_MD_CTX_init(&ctx);

    for (idx = 0; ssl_get_handshake_digest(idx, &mask, &md); idx++) {
        if (ssl_get_algorithm2(s) & mask) {
            int hashsize = EVP_MD_size(md);
            EVP_MD_CTX *hdgst = s->s3->handshake_dgst[idx];
            if (!hdgst || hashsize < 0 ||
                hashsize > (int)(sizeof buf - (size_t)(q - buf))) {
                /* internal error: 'buf' is too small for this cipersuite! */
                err = 1;
            } else {
                if (!EVP_MD_CTX_copy_ex(&ctx, hdgst) ||
                    !EVP_DigestFinal_ex(&ctx, q, &i) ||
                    (i != (unsigned int)hashsize))
                    err = 1;
                q += hashsize;
            }
        }
    }

    if (!tls1_PRF(ssl_get_algorithm2(s), str, slen, buf, (int)(q - buf),
        NULL, 0, NULL, 0, NULL, 0,
        s->session->master_key, s->session->master_key_length,
        out, buf2, sizeof buf2))
        err = 1;
    EVP_MD_CTX_cleanup(&ctx);

    if (err)
        return 0;
    else
        return sizeof buf2;
}

int
tls1_mac(SSL *ssl, unsigned char *md, int send)
{
    SSL3_RECORD *rec;
    unsigned char *seq;
    EVP_MD_CTX *hash;
    size_t md_size, orig_len;
    EVP_MD_CTX hmac, *mac_ctx;
    unsigned char header[13];
    int stream_mac = (send ?
        (ssl->mac_flags & SSL_MAC_FLAG_WRITE_MAC_STREAM) :
        (ssl->mac_flags & SSL_MAC_FLAG_READ_MAC_STREAM));
    int t;

    if (send) {
        rec = &(ssl->s3->wrec);
        seq = &(ssl->s3->write_sequence[0]);
        hash = ssl->write_hash;
    } else {
        rec = &(ssl->s3->rrec);
        seq = &(ssl->s3->read_sequence[0]);
        hash = ssl->read_hash;
    }

    t = EVP_MD_CTX_size(hash);
    OPENSSL_assert(t >= 0);
    md_size = t;

    /* I should fix this up TLS TLS TLS TLS TLS XXXXXXXX */
    if (stream_mac) {
        mac_ctx = hash;
    } else {
        if (!EVP_MD_CTX_copy(&hmac, hash))
            return -1;
        mac_ctx = &hmac;
    }

    memcpy(header, seq, SSL3_SEQUENCE_SIZE);

    /* kludge: tls1_cbc_remove_padding passes padding length in rec->type */
    orig_len = rec->length + md_size + ((unsigned int)rec->type >> 8);
    rec->type &= 0xff;

    header[8] = rec->type;
    header[9] = (unsigned char)(ssl->version >> 8);
    header[10] = (unsigned char)(ssl->version);
    header[11] = (rec->length) >> 8;
    header[12] = (rec->length) & 0xff;

    if (!send &&
        EVP_CIPHER_CTX_mode(ssl->enc_read_ctx) == EVP_CIPH_CBC_MODE &&
        ssl3_cbc_record_digest_supported(mac_ctx)) {
        /* This is a CBC-encrypted record. We must avoid leaking any
         * timing-side channel information about how many blocks of
         * data we are hashing because that gives an attacker a
         * timing-oracle. */
        if (!ssl3_cbc_digest_record(mac_ctx,
            md, &md_size, header, rec->input,
            rec->length + md_size, orig_len,
            ssl->s3->read_mac_secret,
            ssl->s3->read_mac_secret_size,
            0 /* not SSLv3 */))
            return -1;
    } else {
        EVP_DigestSignUpdate(mac_ctx, header, sizeof(header));
        EVP_DigestSignUpdate(mac_ctx, rec->input, rec->length);
        t = EVP_DigestSignFinal(mac_ctx, md, &md_size);
        OPENSSL_assert(t > 0);
    }

    if (!stream_mac)
        EVP_MD_CTX_cleanup(&hmac);

    ssl3_record_sequence_increment(seq);

    return (md_size);
}

int
tls1_generate_master_secret(SSL *s, unsigned char *out, unsigned char *p,
    int len)
{
    unsigned char buff[SSL_MAX_MASTER_KEY_LENGTH];

    tls1_PRF(ssl_get_algorithm2(s),
        TLS_MD_MASTER_SECRET_CONST, TLS_MD_MASTER_SECRET_CONST_SIZE,
        s->s3->client_random, SSL3_RANDOM_SIZE, NULL, 0,
        s->s3->server_random, SSL3_RANDOM_SIZE, NULL, 0,
        p, len, s->session->master_key, buff, sizeof buff);

    return (SSL3_MASTER_SECRET_SIZE);
}

int
tls1_export_keying_material(SSL *s, unsigned char *out, size_t olen,
    const char *label, size_t llen, const unsigned char *context,
    size_t contextlen, int use_context)
{
    unsigned char *buff;
    unsigned char *val = NULL;
    size_t vallen, currentvalpos;
    int rv;

    buff = malloc(olen);
    if (buff == NULL)
        goto err2;

    /* construct PRF arguments
     * we construct the PRF argument ourself rather than passing separate
     * values into the TLS PRF to ensure that the concatenation of values
     * does not create a prohibited label.
     */
    vallen = llen + SSL3_RANDOM_SIZE * 2;
    if (use_context) {
        vallen += 2 + contextlen;
    }

    val = malloc(vallen);
    if (val == NULL)
        goto err2;
    currentvalpos = 0;
    memcpy(val + currentvalpos, (unsigned char *) label, llen);
    currentvalpos += llen;
    memcpy(val + currentvalpos, s->s3->client_random, SSL3_RANDOM_SIZE);
    currentvalpos += SSL3_RANDOM_SIZE;
    memcpy(val + currentvalpos, s->s3->server_random, SSL3_RANDOM_SIZE);
    currentvalpos += SSL3_RANDOM_SIZE;

    if (use_context) {
        val[currentvalpos] = (contextlen >> 8) & 0xff;
        currentvalpos++;
        val[currentvalpos] = contextlen & 0xff;
        currentvalpos++;
        if ((contextlen > 0) || (context != NULL)) {
            memcpy(val + currentvalpos, context, contextlen);
        }
    }

    /* disallow prohibited labels
     * note that SSL3_RANDOM_SIZE > max(prohibited label len) =
     * 15, so size of val > max(prohibited label len) = 15 and the
     * comparisons won't have buffer overflow
     */
    if (memcmp(val, TLS_MD_CLIENT_FINISH_CONST,
        TLS_MD_CLIENT_FINISH_CONST_SIZE) == 0)
        goto err1;
    if (memcmp(val, TLS_MD_SERVER_FINISH_CONST,
        TLS_MD_SERVER_FINISH_CONST_SIZE) == 0)
        goto err1;
    if (memcmp(val, TLS_MD_MASTER_SECRET_CONST,
        TLS_MD_MASTER_SECRET_CONST_SIZE) == 0)
        goto err1;
    if (memcmp(val, TLS_MD_KEY_EXPANSION_CONST,
        TLS_MD_KEY_EXPANSION_CONST_SIZE) == 0)
        goto err1;

    rv = tls1_PRF(ssl_get_algorithm2(s),
        val, vallen, NULL, 0, NULL, 0, NULL, 0, NULL, 0,
        s->session->master_key, s->session->master_key_length,
        out, buff, olen);

    goto ret;
err1:
    SSLerr(SSL_F_TLS1_EXPORT_KEYING_MATERIAL,
        SSL_R_TLS_ILLEGAL_EXPORTER_LABEL);
    rv = 0;
    goto ret;
err2:
    SSLerr(SSL_F_TLS1_EXPORT_KEYING_MATERIAL, ERR_R_MALLOC_FAILURE);
    rv = 0;
ret:
    free(buff);
    free(val);

    return (rv);
}



/* MAX_HASH_BIT_COUNT_BYTES is the maximum number of bytes in the hash's length
 * field. (SHA-384/512 have 128-bit length.) */
#define MAX_HASH_BIT_COUNT_BYTES 16

/* MAX_HASH_BLOCK_SIZE is the maximum hash block size that we'll support.
 * Currently SHA-384/512 has a 128-byte block size and that's the largest
 * supported by TLS.) */
#define MAX_HASH_BLOCK_SIZE 128

/* Some utility functions are needed:
 *
 * These macros return the given value with the MSB copied to all the other
 * bits. They use the fact that arithmetic shift shifts-in the sign bit.
 * However, this is not ensured by the C standard so you may need to replace
 * them with something else on odd CPUs. */
#define DUPLICATE_MSB_TO_ALL(x) ((unsigned)((int)(x) >> (sizeof(int) * 8 - 1)))
#define DUPLICATE_MSB_TO_ALL_8(x) ((unsigned char)(DUPLICATE_MSB_TO_ALL(x)))

/* constant_time_lt returns 0xff if a<b and 0x00 otherwise. */
static unsigned
constant_time_lt(unsigned a, unsigned b)
{
    a -= b;
    return DUPLICATE_MSB_TO_ALL(a);
}

/* constant_time_ge returns 0xff if a>=b and 0x00 otherwise. */
static unsigned
constant_time_ge(unsigned a, unsigned b)
{
    a -= b;
    return DUPLICATE_MSB_TO_ALL(~a);
}

/* constant_time_eq_8 returns 0xff if a==b and 0x00 otherwise. */
static unsigned char
constant_time_eq_8(unsigned a, unsigned b)
{
    unsigned c = a ^ b;
    c--;
    return DUPLICATE_MSB_TO_ALL_8(c);
}

/* ssl3_cbc_remove_padding removes padding from the decrypted, SSLv3, CBC
 * record in |rec| by updating |rec->length| in constant time.
 *
 * block_size: the block size of the cipher used to encrypt the record.
 * returns:
 *   0: (in non-constant time) if the record is publicly invalid.
 *   1: if the padding was valid
 *  -1: otherwise. */
int
ssl3_cbc_remove_padding(const SSL* s, SSL3_RECORD *rec, unsigned block_size,
    unsigned mac_size)
{
    unsigned padding_length, good;
    const unsigned overhead = 1 /* padding length byte */ + mac_size;

    /* These lengths are all public so we can test them in non-constant
     * time. */
    if (overhead > rec->length)
        return 0;

    padding_length = rec->data[rec->length - 1];
    good = constant_time_ge(rec->length, padding_length + overhead);
    /* SSLv3 requires that the padding is minimal. */
    good &= constant_time_ge(block_size, padding_length + 1);
    padding_length = good & (padding_length + 1);
    rec->length -= padding_length;
    rec->type |= padding_length << 8; /* kludge: pass padding length */
    return (int)((good & 1) | (~good & -1));
}

/* tls1_cbc_remove_padding removes the CBC padding from the decrypted, TLS, CBC
 * record in |rec| in constant time and returns 1 if the padding is valid and
 * -1 otherwise. It also removes any explicit IV from the start of the record
 * without leaking any timing about whether there was enough space after the
 * padding was removed.
 *
 * block_size: the block size of the cipher used to encrypt the record.
 * returns:
 *   0: (in non-constant time) if the record is publicly invalid.
 *   1: if the padding was valid
 *  -1: otherwise. */
int
tls1_cbc_remove_padding(const SSL* s, SSL3_RECORD *rec, unsigned block_size,
    unsigned mac_size)
{
    unsigned padding_length, good, to_check, i;
    const unsigned overhead = 1 /* padding length byte */ + mac_size;

    /* Check if version requires explicit IV */
    if (SSL_USE_EXPLICIT_IV(s)) {
        /* These lengths are all public so we can test them in
         * non-constant time.
         */
        if (overhead + block_size > rec->length)
            return 0;
        /* We can now safely skip explicit IV */
        rec->data += block_size;
        rec->input += block_size;
        rec->length -= block_size;
    } else if (overhead > rec->length)
        return 0;

    padding_length = rec->data[rec->length - 1];

    /* NB: if compression is in operation the first packet may not be of
     * even length so the padding bug check cannot be performed. This bug
     * workaround has been around since SSLeay so hopefully it is either
     * fixed now or no buggy implementation supports compression [steve]
     * (We don't support compression either, so it's not in operation.)
     */
    if ((s->options & SSL_OP_TLS_BLOCK_PADDING_BUG)) {
        /* First packet is even in size, so check */
        if ((memcmp(s->s3->read_sequence, "\0\0\0\0\0\0\0\0",
            SSL3_SEQUENCE_SIZE) == 0) && !(padding_length & 1)) {
            s->s3->flags|=TLS1_FLAGS_TLS_PADDING_BUG;
        }
        if ((s->s3->flags & TLS1_FLAGS_TLS_PADDING_BUG) &&
            padding_length > 0) {
            padding_length--;
        }
    }

    if (EVP_CIPHER_flags(s->enc_read_ctx->cipher) & EVP_CIPH_FLAG_AEAD_CIPHER) {
        /* padding is already verified */
        rec->length -= padding_length + 1;
        return 1;
    }

    good = constant_time_ge(rec->length, overhead + padding_length);
    /* The padding consists of a length byte at the end of the record and
     * then that many bytes of padding, all with the same value as the
     * length byte. Thus, with the length byte included, there are i+1
     * bytes of padding.
     *
     * We can't check just |padding_length+1| bytes because that leaks
     * decrypted information. Therefore we always have to check the maximum
     * amount of padding possible. (Again, the length of the record is
     * public information so we can use it.) */
    to_check = 255; /* maximum amount of padding. */
    if (to_check > rec->length - 1)
        to_check = rec->length - 1;

    for (i = 0; i < to_check; i++) {
        unsigned char mask = constant_time_ge(padding_length, i);
        unsigned char b = rec->data[rec->length - 1 - i];
        /* The final |padding_length+1| bytes should all have the value
         * |padding_length|. Therefore the XOR should be zero. */
        good &= ~(mask&(padding_length ^ b));
    }

    /* If any of the final |padding_length+1| bytes had the wrong value,
     * one or more of the lower eight bits of |good| will be cleared. We
     * AND the bottom 8 bits together and duplicate the result to all the
     * bits. */
    good &= good >> 4;
    good &= good >> 2;
    good &= good >> 1;
    good <<= sizeof(good)*8 - 1;
    good = DUPLICATE_MSB_TO_ALL(good);

    padding_length = good & (padding_length + 1);
    rec->length -= padding_length;
    rec->type |= padding_length<<8; /* kludge: pass padding length */

    return (int)((good & 1) | (~good & -1));
}

/* ssl3_cbc_copy_mac copies |md_size| bytes from the end of |rec| to |out| in
 * constant time (independent of the concrete value of rec->length, which may
 * vary within a 256-byte window).
 *
 * ssl3_cbc_remove_padding or tls1_cbc_remove_padding must be called prior to
 * this function.
 *
 * On entry:
 *   rec->orig_len >= md_size
 *   md_size <= EVP_MAX_MD_SIZE
 *
 * If CBC_MAC_ROTATE_IN_PLACE is defined then the rotation is performed with
 * variable accesses in a 64-byte-aligned buffer. Assuming that this fits into
 * a single or pair of cache-lines, then the variable memory accesses don't
 * actually affect the timing. CPUs with smaller cache-lines [if any] are
 * not multi-core and are not considered vulnerable to cache-timing attacks.
 */
#define CBC_MAC_ROTATE_IN_PLACE

void
ssl3_cbc_copy_mac(unsigned char* out, const SSL3_RECORD *rec,
    unsigned md_size, unsigned orig_len)
{
#if defined(CBC_MAC_ROTATE_IN_PLACE)
    unsigned char rotated_mac_buf[64 + EVP_MAX_MD_SIZE];
    unsigned char *rotated_mac;
#else
    unsigned char rotated_mac[EVP_MAX_MD_SIZE];
#endif

    /* mac_end is the index of |rec->data| just after the end of the MAC. */
    unsigned mac_end = rec->length;
    unsigned mac_start = mac_end - md_size;
    /* scan_start contains the number of bytes that we can ignore because
     * the MAC's position can only vary by 255 bytes. */
    unsigned scan_start = 0;
    unsigned i, j;
    unsigned div_spoiler;
    unsigned rotate_offset;

    OPENSSL_assert(orig_len >= md_size);
    OPENSSL_assert(md_size <= EVP_MAX_MD_SIZE);

#if defined(CBC_MAC_ROTATE_IN_PLACE)
    rotated_mac = rotated_mac_buf + ((0 - (size_t)rotated_mac_buf)&63);
#endif

    /* This information is public so it's safe to branch based on it. */
    if (orig_len > md_size + 255 + 1)
        scan_start = orig_len - (md_size + 255 + 1);
    /* div_spoiler contains a multiple of md_size that is used to cause the
     * modulo operation to be constant time. Without this, the time varies
     * based on the amount of padding when running on Intel chips at least.
     *
     * The aim of right-shifting md_size is so that the compiler doesn't
     * figure out that it can remove div_spoiler as that would require it
     * to prove that md_size is always even, which I hope is beyond it. */
    div_spoiler = md_size >> 1;
    div_spoiler <<= (sizeof(div_spoiler) - 1) * 8;
    rotate_offset = (div_spoiler + mac_start - scan_start) % md_size;

    memset(rotated_mac, 0, md_size);
    for (i = scan_start, j = 0; i < orig_len; i++) {
        unsigned char mac_started = constant_time_ge(i, mac_start);
        unsigned char mac_ended = constant_time_ge(i, mac_end);
        unsigned char b = rec->data[i];
        rotated_mac[j++] |= b & mac_started & ~mac_ended;
        j &= constant_time_lt(j, md_size);
    }

    /* Now rotate the MAC */
#if defined(CBC_MAC_ROTATE_IN_PLACE)
    j = 0;
    for (i = 0; i < md_size; i++) {
        /* in case cache-line is 32 bytes, touch second line */
        ((volatile unsigned char *)rotated_mac)[rotate_offset^32];
        out[j++] = rotated_mac[rotate_offset++];
        rotate_offset &= constant_time_lt(rotate_offset, md_size);
    }
#else
    memset(out, 0, md_size);
    rotate_offset = md_size - rotate_offset;
    rotate_offset &= constant_time_lt(rotate_offset, md_size);
    for (i = 0; i < md_size; i++) {
        for (j = 0; j < md_size; j++)
            out[j] |= rotated_mac[i] & constant_time_eq_8(j, rotate_offset);
        rotate_offset++;
        rotate_offset &= constant_time_lt(rotate_offset, md_size);
    }
#endif
}

/* u32toLE serialises an unsigned, 32-bit number (n) as four bytes at (p) in
 * little-endian order. The value of p is advanced by four. */
#define u32toLE(n, p) \
    (*((p)++)=(unsigned char)(n), \
     *((p)++)=(unsigned char)(n>>8), \
     *((p)++)=(unsigned char)(n>>16), \
     *((p)++)=(unsigned char)(n>>24))

/* These functions serialize the state of a hash and thus perform the standard
 * "final" operation without adding the padding and length that such a function
 * typically does. */
static void
tls1_md5_final_raw(void* ctx, unsigned char *md_out)
{
    MD5_CTX *md5 = ctx;
    u32toLE(md5->A, md_out);
    u32toLE(md5->B, md_out);
    u32toLE(md5->C, md_out);
    u32toLE(md5->D, md_out);
}

static void
tls1_sha1_final_raw(void* ctx, unsigned char *md_out)
{
    SHA_CTX *sha1 = ctx;
    l2n(sha1->h0, md_out);
    l2n(sha1->h1, md_out);
    l2n(sha1->h2, md_out);
    l2n(sha1->h3, md_out);
    l2n(sha1->h4, md_out);
}
#define LARGEST_DIGEST_CTX SHA_CTX

static void
tls1_sha256_final_raw(void* ctx, unsigned char *md_out)
{
    SHA256_CTX *sha256 = ctx;
    unsigned i;

    for (i = 0; i < 8; i++) {
        l2n(sha256->h[i], md_out);
    }
}
#undef  LARGEST_DIGEST_CTX
#define LARGEST_DIGEST_CTX SHA256_CTX

static void
tls1_sha512_final_raw(void* ctx, unsigned char *md_out)
{
    SHA512_CTX *sha512 = ctx;
    unsigned i;

    for (i = 0; i < 8; i++) {
        l2n8(sha512->h[i], md_out);
    }
}
#undef  LARGEST_DIGEST_CTX
#define LARGEST_DIGEST_CTX SHA512_CTX

/* ssl3_cbc_record_digest_supported returns 1 iff |ctx| uses a hash function
 * which ssl3_cbc_digest_record supports. */
char
ssl3_cbc_record_digest_supported(const EVP_MD_CTX *ctx)
{
    switch (EVP_MD_CTX_type(ctx)) {
    case NID_md5:
    case NID_sha1:
    case NID_sha224:
    case NID_sha256:
    case NID_sha384:
    case NID_sha512:
        return 1;
    default:
        return 0;
    }
}

/* ssl3_cbc_digest_record computes the MAC of a decrypted, padded SSLv3/TLS
 * record.
 *
 *   ctx: the EVP_MD_CTX from which we take the hash function.
 *     ssl3_cbc_record_digest_supported must return true for this EVP_MD_CTX.
 *   md_out: the digest output. At most EVP_MAX_MD_SIZE bytes will be written.
 *   md_out_size: if non-NULL, the number of output bytes is written here.
 *   header: the 13-byte, TLS record header.
 *   data: the record data itself, less any preceeding explicit IV.
 *   data_plus_mac_size: the secret, reported length of the data and MAC
 *     once the padding has been removed.
 *   data_plus_mac_plus_padding_size: the public length of the whole
 *     record, including padding.
 *   is_sslv3: non-zero if we are to use SSLv3. Otherwise, TLS.
 *
 * On entry: by virtue of having been through one of the remove_padding
 * functions, above, we know that data_plus_mac_size is large enough to contain
 * a padding byte and MAC. (If the padding was invalid, it might contain the
 * padding too. ) */
int
ssl3_cbc_digest_record(const EVP_MD_CTX *ctx, unsigned char* md_out,
    size_t* md_out_size, const unsigned char header[13],
    const unsigned char *data, size_t data_plus_mac_size,
    size_t data_plus_mac_plus_padding_size, const unsigned char *mac_secret,
    unsigned mac_secret_length, char is_sslv3)
{
    union { double align;
        unsigned char c[sizeof(LARGEST_DIGEST_CTX)];
    } md_state;
    void (*md_final_raw)(void *ctx, unsigned char *md_out);
    void (*md_transform)(void *ctx, const unsigned char *block);
    unsigned md_size, md_block_size = 64;
    unsigned sslv3_pad_length = 40, header_length, variance_blocks,
    len, max_mac_bytes, num_blocks,
    num_starting_blocks, k, mac_end_offset, c, index_a, index_b;
    unsigned int bits;  /* at most 18 bits */
    unsigned char length_bytes[MAX_HASH_BIT_COUNT_BYTES];
    /* hmac_pad is the masked HMAC key. */
    unsigned char hmac_pad[MAX_HASH_BLOCK_SIZE];
    unsigned char first_block[MAX_HASH_BLOCK_SIZE];
    unsigned char mac_out[EVP_MAX_MD_SIZE];
    unsigned i, j, md_out_size_u;
    EVP_MD_CTX md_ctx;
    /* mdLengthSize is the number of bytes in the length field that terminates
    * the hash. */
    unsigned md_length_size = 8;
    char length_is_big_endian = 1;

    /* This is a, hopefully redundant, check that allows us to forget about
     * many possible overflows later in this function. */
    OPENSSL_assert(data_plus_mac_plus_padding_size < 1024*1024);

    switch (EVP_MD_CTX_type(ctx)) {
    case NID_md5:
        MD5_Init((MD5_CTX*)md_state.c);
        md_final_raw = tls1_md5_final_raw;
        md_transform = (void(*)(void *ctx, const unsigned char *block)) MD5_Transform;
        md_size = 16;
        sslv3_pad_length = 48;
        length_is_big_endian = 0;
        break;
    case NID_sha1:
        SHA1_Init((SHA_CTX*)md_state.c);
        md_final_raw = tls1_sha1_final_raw;
        md_transform = (void(*)(void *ctx, const unsigned char *block)) SHA1_Transform;
        md_size = 20;
        break;
    case NID_sha224:
        SHA224_Init((SHA256_CTX*)md_state.c);
        md_final_raw = tls1_sha256_final_raw;
        md_transform = (void(*)(void *ctx, const unsigned char *block)) SHA256_Transform;
        md_size = 224/8;
        break;
    case NID_sha256:
        SHA256_Init((SHA256_CTX*)md_state.c);
        md_final_raw = tls1_sha256_final_raw;
        md_transform = (void(*)(void *ctx, const unsigned char *block)) SHA256_Transform;
        md_size = 32;
        break;
    case NID_sha384:
        SHA384_Init((SHA512_CTX*)md_state.c);
        md_final_raw = tls1_sha512_final_raw;
        md_transform = (void(*)(void *ctx, const unsigned char *block)) SHA512_Transform;
        md_size = 384/8;
        md_block_size = 128;
        md_length_size = 16;
        break;
    case NID_sha512:
        SHA512_Init((SHA512_CTX*)md_state.c);
        md_final_raw = tls1_sha512_final_raw;
        md_transform = (void(*)(void *ctx, const unsigned char *block)) SHA512_Transform;
        md_size = 64;
        md_block_size = 128;
        md_length_size = 16;
        break;
    default:
        /* ssl3_cbc_record_digest_supported should have been
         * called first to check that the hash function is
         * supported. */
        OPENSSL_assert(0);
        if (md_out_size)
            *md_out_size = 0;
        return 0;
    }

    OPENSSL_assert(md_length_size <= MAX_HASH_BIT_COUNT_BYTES);
    OPENSSL_assert(md_block_size <= MAX_HASH_BLOCK_SIZE);
    OPENSSL_assert(md_size <= EVP_MAX_MD_SIZE);

    header_length = 13;
    if (is_sslv3) {
        header_length = mac_secret_length + sslv3_pad_length +
            8 /* sequence number */ +
            1 /* record type */ +
            2 /* record length */;
    }

    /* variance_blocks is the number of blocks of the hash that we have to
     * calculate in constant time because they could be altered by the
     * padding value.
     *
     * In SSLv3, the padding must be minimal so the end of the plaintext
     * varies by, at most, 15+20 = 35 bytes. (We conservatively assume that
     * the MAC size varies from 0..20 bytes.) In case the 9 bytes of hash
     * termination (0x80 + 64-bit length) don't fit in the final block, we
     * say that the final two blocks can vary based on the padding.
     *
     * TLSv1 has MACs up to 48 bytes long (SHA-384) and the padding is not
     * required to be minimal. Therefore we say that the final six blocks
     * can vary based on the padding.
     *
     * Later in the function, if the message is short and there obviously
     * cannot be this many blocks then variance_blocks can be reduced. */
    variance_blocks = is_sslv3 ? 2 : 6;
    /* From now on we're dealing with the MAC, which conceptually has 13
     * bytes of `header' before the start of the data (TLS) or 71/75 bytes
     * (SSLv3) */
    len = data_plus_mac_plus_padding_size + header_length;
    /* max_mac_bytes contains the maximum bytes of bytes in the MAC, including
    * |header|, assuming that there's no padding. */
    max_mac_bytes = len - md_size - 1;
    /* num_blocks is the maximum number of hash blocks. */
    num_blocks = (max_mac_bytes + 1 + md_length_size + md_block_size - 1) / md_block_size;
    /* In order to calculate the MAC in constant time we have to handle
     * the final blocks specially because the padding value could cause the
     * end to appear somewhere in the final |variance_blocks| blocks and we
     * can't leak where. However, |num_starting_blocks| worth of data can
     * be hashed right away because no padding value can affect whether
     * they are plaintext. */
    num_starting_blocks = 0;
    /* k is the starting byte offset into the conceptual header||data where
     * we start processing. */
    k = 0;
    /* mac_end_offset is the index just past the end of the data to be
     * MACed. */
    mac_end_offset = data_plus_mac_size + header_length - md_size;
    /* c is the index of the 0x80 byte in the final hash block that
     * contains application data. */
    c = mac_end_offset % md_block_size;
    /* index_a is the hash block number that contains the 0x80 terminating
     * value. */
    index_a = mac_end_offset / md_block_size;
    /* index_b is the hash block number that contains the 64-bit hash
     * length, in bits. */
    index_b = (mac_end_offset + md_length_size) / md_block_size;
    /* bits is the hash-length in bits. It includes the additional hash
     * block for the masked HMAC key, or whole of |header| in the case of
     * SSLv3. */

    /* For SSLv3, if we're going to have any starting blocks then we need
     * at least two because the header is larger than a single block. */
    if (num_blocks > variance_blocks + (is_sslv3 ? 1 : 0)) {
        num_starting_blocks = num_blocks - variance_blocks;
        k = md_block_size*num_starting_blocks;
    }

    bits = 8*mac_end_offset;
    if (!is_sslv3) {
        /* Compute the initial HMAC block. For SSLv3, the padding and
         * secret bytes are included in |header| because they take more
         * than a single block. */
        bits += 8*md_block_size;
        memset(hmac_pad, 0, md_block_size);
        OPENSSL_assert(mac_secret_length <= sizeof(hmac_pad));
        memcpy(hmac_pad, mac_secret, mac_secret_length);
        for (i = 0; i < md_block_size; i++)
            hmac_pad[i] ^= 0x36;

        md_transform(md_state.c, hmac_pad);
    }

    if (length_is_big_endian) {
        memset(length_bytes, 0, md_length_size - 4);
        length_bytes[md_length_size - 4] = (unsigned char)(bits >> 24);
        length_bytes[md_length_size - 3] = (unsigned char)(bits >> 16);
        length_bytes[md_length_size - 2] = (unsigned char)(bits >> 8);
        length_bytes[md_length_size - 1] = (unsigned char)bits;
    } else {
        memset(length_bytes, 0, md_length_size);
        length_bytes[md_length_size - 5] = (unsigned char)(bits >> 24);
        length_bytes[md_length_size - 6] = (unsigned char)(bits >> 16);
        length_bytes[md_length_size - 7] = (unsigned char)(bits >> 8);
        length_bytes[md_length_size - 8] = (unsigned char)bits;
    }

    if (k > 0) {
        if (is_sslv3) {
            /* The SSLv3 header is larger than a single block.
             * overhang is the number of bytes beyond a single
             * block that the header consumes: either 7 bytes
             * (SHA1) or 11 bytes (MD5). */
            unsigned overhang = header_length - md_block_size;
            md_transform(md_state.c, header);
            memcpy(first_block, header + md_block_size, overhang);
            memcpy(first_block + overhang, data, md_block_size - overhang);
            md_transform(md_state.c, first_block);
            for (i = 1; i < k/md_block_size - 1; i++)
                md_transform(md_state.c, data + md_block_size*i - overhang);
        } else {
            /* k is a multiple of md_block_size. */
            memcpy(first_block, header, 13);
            memcpy(first_block + 13, data, md_block_size - 13);
            md_transform(md_state.c, first_block);
            for (i = 1; i < k/md_block_size; i++)
                md_transform(md_state.c, data + md_block_size*i - 13);
        }
    }

    memset(mac_out, 0, sizeof(mac_out));

    /* We now process the final hash blocks. For each block, we construct
     * it in constant time. If the |i==index_a| then we'll include the 0x80
     * bytes and zero pad etc. For each block we selectively copy it, in
     * constant time, to |mac_out|. */
    for (i = num_starting_blocks; i <= num_starting_blocks + variance_blocks; i++) {
        unsigned char block[MAX_HASH_BLOCK_SIZE];
        unsigned char is_block_a = constant_time_eq_8(i, index_a);
        unsigned char is_block_b = constant_time_eq_8(i, index_b);
        for (j = 0; j < md_block_size; j++) {
            unsigned char b = 0, is_past_c, is_past_cp1;
            if (k < header_length)
                b = header[k];
            else if (k < data_plus_mac_plus_padding_size + header_length)
                b = data[k - header_length];
            k++;

            is_past_c = is_block_a & constant_time_ge(j, c);
            is_past_cp1 = is_block_a & constant_time_ge(j, c + 1);
            /* If this is the block containing the end of the
             * application data, and we are at the offset for the
             * 0x80 value, then overwrite b with 0x80. */
            b = (b&~is_past_c) | (0x80&is_past_c);
            /* If this the the block containing the end of the
             * application data and we're past the 0x80 value then
             * just write zero. */
            b = b&~is_past_cp1;
            /* If this is index_b (the final block), but not
             * index_a (the end of the data), then the 64-bit
             * length didn't fit into index_a and we're having to
             * add an extra block of zeros. */
            b &= ~is_block_b | is_block_a;

            /* The final bytes of one of the blocks contains the
             * length. */
            if (j >= md_block_size - md_length_size) {
                /* If this is index_b, write a length byte. */
                b = (b&~is_block_b) | (is_block_b&length_bytes[j - (md_block_size - md_length_size)]);
            }
            block[j] = b;
        }

        md_transform(md_state.c, block);
        md_final_raw(md_state.c, block);
        /* If this is index_b, copy the hash value to |mac_out|. */
        for (j = 0; j < md_size; j++)
            mac_out[j] |= block[j]&is_block_b;
    }

    EVP_MD_CTX_init(&md_ctx);
    if (!EVP_DigestInit_ex(&md_ctx, ctx->digest, NULL /* engine */)) {
        EVP_MD_CTX_cleanup(&md_ctx);
        return 0;
    }
    if (is_sslv3) {
        /* We repurpose |hmac_pad| to contain the SSLv3 pad2 block. */
        memset(hmac_pad, 0x5c, sslv3_pad_length);

        EVP_DigestUpdate(&md_ctx, mac_secret, mac_secret_length);
        EVP_DigestUpdate(&md_ctx, hmac_pad, sslv3_pad_length);
        EVP_DigestUpdate(&md_ctx, mac_out, md_size);
    } else {
        /* Complete the HMAC in the standard manner. */
        for (i = 0; i < md_block_size; i++)
            hmac_pad[i] ^= 0x6a;

        EVP_DigestUpdate(&md_ctx, hmac_pad, md_block_size);
        EVP_DigestUpdate(&md_ctx, mac_out, md_size);
    }
    EVP_DigestFinal(&md_ctx, md_out, &md_out_size_u);
    if (md_out_size)
        *md_out_size = md_out_size_u;
    EVP_MD_CTX_cleanup(&md_ctx);

    return 1;
}
