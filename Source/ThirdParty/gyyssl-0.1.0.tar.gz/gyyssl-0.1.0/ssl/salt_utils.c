/* ssl/salt_utils.c */

#include <limits.h>
#include <stdio.h>
#include <string.h>

#include "ssl_locl.h"

#include <openssl/buffer.h>
#include <openssl/evp.h>
#include <openssl/objects.h>
#include <openssl/x509.h>


/**
 * Alloc the write buffer of a SSL connection.
 *
 * \return  1 if succ, or 0 if failed.
 */
int
ssl_setup_write_buffer(SSL *s)
{
	unsigned char *p;
	size_t len, align, headerlen;

    headerlen = SSL3_RT_HEADER_LENGTH;

	align = (-SSL3_RT_HEADER_LENGTH) & (SSL3_ALIGN_PAYLOAD - 1);

	if (s->s3->wbuf.buf == NULL) {
		len = s->max_send_fragment +
		    SSL3_RT_SEND_MAX_ENCRYPTED_OVERHEAD + headerlen + align;
		if (!(s->options & SSL_OP_DONT_INSERT_EMPTY_FRAGMENTS))
			len += headerlen + align +
			    SSL3_RT_SEND_MAX_ENCRYPTED_OVERHEAD;

		if ((p = malloc(len)) == NULL)
			goto err;
		s->s3->wbuf.buf = p;
		s->s3->wbuf.len = len;
	}

	return 1;

err:
	SSLerr(SSL_F_SSL3_SETUP_WRITE_BUFFER, ERR_R_MALLOC_FAILURE);
	return 0;
}

int
ssl_setup_read_buffer(SSL *s)
{
	unsigned char *p;
	size_t len, align, headerlen;

    headerlen = SSL3_RT_HEADER_LENGTH;

	align = (-SSL3_RT_HEADER_LENGTH) & (SSL3_ALIGN_PAYLOAD - 1);

	if (s->s3->rbuf.buf == NULL) {
		len = SSL3_RT_MAX_PLAIN_LENGTH +
		    SSL3_RT_MAX_ENCRYPTED_OVERHEAD + headerlen + align;
		if ((p = malloc(len)) == NULL)
			goto err;
		s->s3->rbuf.buf = p;
		s->s3->rbuf.len = len;
	}

	s->packet = &(s->s3->rbuf.buf[0]);
	return 1;

err:
	SSLerr(SSL_F_SSL3_SETUP_READ_BUFFER, ERR_R_MALLOC_FAILURE);
	return 0;
}

int
ssl_setup_init_buffer(SSL *s)
{
	BUF_MEM *buf = NULL;

	if (s->init_buf != NULL)
		return (1);

	if ((buf = BUF_MEM_new()) == NULL)
		goto err;
	if (!BUF_MEM_grow(buf, SSL3_RT_MAX_PLAIN_LENGTH))
		goto err;

	s->init_buf = buf;
	return (1);

err:
	BUF_MEM_free(buf);
	return (0);
}

int
ssl_setup_buffers(SSL *s)
{
	if (!ssl_setup_read_buffer(s))
		return 0;
	if (!ssl_setup_write_buffer(s))
		return 0;
	return 1;
}

int
ssl_get_cert_type(X509 *x, EVP_PKEY *pkey)
{
	EVP_PKEY *pk;
	int ret = -1, i;

	if (pkey == NULL)
		pk = X509_get_pubkey(x);
	else
		pk = pkey;
	if (pk == NULL)
		goto err;

	i = pk->type;
	if (i == EVP_PKEY_RSA) {
		ret = SSL_PKEY_RSA_ENC;
	} else if (i == EVP_PKEY_DSA) {
		ret = SSL_PKEY_DSA_SIGN;
	}
	else if (i == EVP_PKEY_EC) {
		ret = SSL_PKEY_ECC;
	} else if (i == NID_id_GostR3410_2001 || i == NID_id_GostR3410_2001_cc) {
		ret = SSL_PKEY_GOST01;
	}
err:
	if (!pkey)
		EVP_PKEY_free(pk);
	return (ret);
}

int
ssl_get_verify_alarm_type(long type)
{
	int al;

	switch (type) {
	case X509_V_ERR_UNABLE_TO_GET_ISSUER_CERT:
	case X509_V_ERR_UNABLE_TO_GET_CRL:
	case X509_V_ERR_UNABLE_TO_GET_CRL_ISSUER:
		al = SSL_AD_UNKNOWN_CA;
		break;
	case X509_V_ERR_UNABLE_TO_DECRYPT_CERT_SIGNATURE:
	case X509_V_ERR_UNABLE_TO_DECRYPT_CRL_SIGNATURE:
	case X509_V_ERR_UNABLE_TO_DECODE_ISSUER_PUBLIC_KEY:
	case X509_V_ERR_ERROR_IN_CERT_NOT_BEFORE_FIELD:
	case X509_V_ERR_ERROR_IN_CERT_NOT_AFTER_FIELD:
	case X509_V_ERR_ERROR_IN_CRL_LAST_UPDATE_FIELD:
	case X509_V_ERR_ERROR_IN_CRL_NEXT_UPDATE_FIELD:
	case X509_V_ERR_CERT_NOT_YET_VALID:
	case X509_V_ERR_CRL_NOT_YET_VALID:
	case X509_V_ERR_CERT_UNTRUSTED:
	case X509_V_ERR_CERT_REJECTED:
		al = SSL_AD_BAD_CERTIFICATE;
		break;
	case X509_V_ERR_CERT_SIGNATURE_FAILURE:
	case X509_V_ERR_CRL_SIGNATURE_FAILURE:
		al = SSL_AD_DECRYPT_ERROR;
		break;
	case X509_V_ERR_CERT_HAS_EXPIRED:
	case X509_V_ERR_CRL_HAS_EXPIRED:
		al = SSL_AD_CERTIFICATE_EXPIRED;
		break;
	case X509_V_ERR_CERT_REVOKED:
		al = SSL_AD_CERTIFICATE_REVOKED;
		break;
	case X509_V_ERR_OUT_OF_MEM:
		al = SSL_AD_INTERNAL_ERROR;
		break;
	case X509_V_ERR_DEPTH_ZERO_SELF_SIGNED_CERT:
	case X509_V_ERR_SELF_SIGNED_CERT_IN_CHAIN:
	case X509_V_ERR_UNABLE_TO_GET_ISSUER_CERT_LOCALLY:
	case X509_V_ERR_UNABLE_TO_VERIFY_LEAF_SIGNATURE:
	case X509_V_ERR_CERT_CHAIN_TOO_LONG:
	case X509_V_ERR_PATH_LENGTH_EXCEEDED:
	case X509_V_ERR_INVALID_CA:
		al = SSL_AD_UNKNOWN_CA;
		break;
	case X509_V_ERR_APPLICATION_VERIFICATION:
		al = SSL_AD_HANDSHAKE_FAILURE;
		break;
	case X509_V_ERR_INVALID_PURPOSE:
		al = SSL_AD_UNSUPPORTED_CERTIFICATE;
		break;
	default:
		al = SSL_AD_CERTIFICATE_UNKNOWN;
		break;
	}
	return (al);
}

int
ssl_release_read_buffer(SSL *s)
{
	free(s->s3->rbuf.buf);
	s->s3->rbuf.buf = NULL;
	return 1;
}
int
ssl_release_write_buffer(SSL *s)
{
	free(s->s3->wbuf.buf);
	s->s3->wbuf.buf = NULL;
	return 1;
}

unsigned long
ssl3_output_cert_chain(SSL *s, X509 *x)
{
	unsigned char *p;
	int i;
	unsigned long l = 7;

	int no_chain;
	if ((s->mode & SSL_MODE_NO_AUTO_CHAIN) || s->ctx->extra_certs)
		no_chain = 1;
	else
		no_chain = 0;

	/* TLSv1 sends a chain with nothing in it, instead of an alert */
	BUF_MEM *buf = s->init_buf;
	if (!BUF_MEM_grow_clean(buf, 10)) {
		SSLerr(SSL_F_SSL3_OUTPUT_CERT_CHAIN, ERR_R_BUF_LIB);
		return (0);
	}
    if (x != NULL)
    {
        if (no_chain)
        {
            if (ssl3_add_cert_to_buf(buf, &l, x))
                return (0);
        }
        else
        {
            X509_STORE_CTX xs_ctx;

            if (!X509_STORE_CTX_init(&xs_ctx, s->ctx->cert_store, x, NULL))
            {
                SSLerr(SSL_F_SSL3_OUTPUT_CERT_CHAIN, ERR_R_X509_LIB);
                return (0);
            }
            X509_verify_cert(&xs_ctx);
            /* Don't leave errors in the queue */
            ERR_clear_error();
            for (i = 0; i < sk_X509_num(xs_ctx.chain); i++)
            {
                x = sk_X509_value(xs_ctx.chain, i);

                if (ssl3_add_cert_to_buf(buf, &l, x))
                {
                    X509_STORE_CTX_cleanup(&xs_ctx);
                    return 0;
                }
            }
            X509_STORE_CTX_cleanup(&xs_ctx);
        }
    }
	/* Thawte special :-) */
	for (i = 0; i < sk_X509_num(s->ctx->extra_certs); i++) {
		x = sk_X509_value(s->ctx->extra_certs, i);
		if (ssl3_add_cert_to_buf(buf, &l, x))
			return (0);
	}

	l -= 7;
	p = (unsigned char *)&(buf->data[4]);
	l2n3(l, p);
	l += 3;
	p = (unsigned char *)&(buf->data[0]);
	*(p++) = SSL3_MT_CERTIFICATE;
	l2n3(l, p);
	l += 4;
	return (l);
}

int
ssl3_add_cert_to_buf(BUF_MEM *buf, unsigned long *l, X509 *x)
{
	int n;
	unsigned char *p;

	n = i2d_X509(x, NULL);
	if (!BUF_MEM_grow_clean(buf, n + (*l) + 3)) {
		SSLerr(SSL_F_SSL3_ADD_CERT_TO_BUF, ERR_R_BUF_LIB);
		return (-1);
	}
	p = (unsigned char *)&(buf->data[*l]);
	l2n3(n, p);
	i2d_X509(x, &p);
	*l += n + 3;

	return (0);
}

long
ssl_get_algorithm2(SSL *s)
{
	long	alg2 = s->s3->tmp.new_cipher->algorithm2;

	if (s->method->ssl3_enc->enc_flags & SSL_ENC_FLAG_SHA256_PRF &&
	    alg2 == (SSL_HANDSHAKE_MAC_DEFAULT|TLS1_PRF))
		return SSL_HANDSHAKE_MAC_SHA256 | TLS1_PRF_SHA256;
	return alg2;
}

void
ssl_fill_hsmsg_header(SSL *s, unsigned int len)
{
	unsigned char *p = (unsigned char *)s->init_buf->data + 1;
	l2n3(len, p);

	s->init_num = SSL3_HM_HEADER_LENGTH + (int)len;
	s->init_off = 0;
}

unsigned char *
ssl_init_hsmsg(SSL *s, uint8_t msg_type)
{
	unsigned char *p = (unsigned char *)s->init_buf->data;

	*(p++) = msg_type;
	l2n3(0, p);

	return p;
}

