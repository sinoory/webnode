/* ssl/salt_methods.c */

#include <stdio.h>

#include "ssl_locl.h"

#include <openssl/buffer.h>
#include <openssl/evp.h>
#include <openssl/objects.h>
#include <openssl/md5.h>

static const SSL_METHOD *
ssl3_get_method(int ver)
{
    if (ver == SSL3_VERSION)
        return (SSLv3_method());
    return (NULL);
}

static const SSL_METHOD *
tls1_get_method(int ver)
{
    if (ver == TLS1_2_VERSION)
        return (TLSv1_2_method());
    if (ver == TLS1_1_VERSION)
        return (TLSv1_1_method());
    if (ver == TLS1_VERSION)
        return (TLSv1_method());
    return (NULL);
}

static const SSL_METHOD *
tls1_get_client_method(int ver)
{
    if (ver == TLS1_2_VERSION)
        return (TLSv1_2_client_method());
    if (ver == TLS1_1_VERSION)
        return (TLSv1_1_client_method());
    if (ver == TLS1_VERSION)
        return (TLSv1_client_method());
    return (NULL);
}

static const SSL_METHOD *
ssl3_get_client_method(int ver)
{
    if (ver == SSL3_VERSION)
        return (SSLv3_client_method());
    return (NULL);
}


static const SSL_METHOD *
ssl23_get_method(int ver)
{
    if (ver == SSL3_VERSION)
        return (SSLv3_method());
    if (ver == TLS1_VERSION)
        return (TLSv1_method());
    if (ver == TLS1_1_VERSION)
        return (TLSv1_1_method());
    if (ver == TLS1_2_VERSION)
        return (TLSv1_2_method());
    return (NULL);
}
static const SSL_METHOD *
ssl23_get_client_method(int ver)
{
    if (ver == SSL3_VERSION)
        return (SSLv3_client_method());
    if (ver == TLS1_VERSION)
        return (TLSv1_client_method());
    if (ver == TLS1_1_VERSION)
        return (TLSv1_1_client_method());
    if (ver == TLS1_2_VERSION)
        return (TLSv1_2_client_method());
    return (NULL);
}

const SSL_METHOD SSLv23_client_method_data = {
    .version = TLS1_2_VERSION,
    .ssl_new = tls1_new,
    .ssl_clear = tls1_clear,
    .ssl_free = tls1_free,
    .ssl_accept = ssl_undefined_function,
    .ssl_connect = ssl23_connect,
    .ssl_read = ssl23_read,
    .ssl_peek = ssl23_peek,
    .ssl_write = ssl23_write,
    .ssl_shutdown = ssl_undefined_function,
    .ssl_get_message = ssl3_get_message,
    .ssl_read_bytes = ssl_recv_subproto,
    .ssl_write_bytes = ssl_write_bytes,
    .ssl_ctrl = ssl3_ctrl,
    .ssl_ctx_ctrl = ssl3_ctx_ctrl,
    .get_cipher_by_char = ssl3_get_cipher_by_char,
    .put_cipher_by_char = ssl3_put_cipher_by_char,
    .ssl_pending = ssl_undefined_const_function,
    .num_ciphers = ssl_num_ciphers,
    .get_cipher = ssl_get_cipher,
    .get_ssl_method = ssl23_get_client_method,
    .get_timeout = ssl23_default_timeout,
    .ssl3_enc = &ssl3_undef_enc_method,
    .ssl_version = ssl_undefined_void_function,
    .ssl_callback_ctrl = ssl3_callback_ctrl,
    .ssl_ctx_callback_ctrl = ssl3_ctx_callback_ctrl,
};

const SSL_METHOD SSLv23_method_data = {
    .version = TLS1_2_VERSION,
    .ssl_new = tls1_new,
    .ssl_clear = tls1_clear,
    .ssl_free = tls1_free,
    .ssl_accept = ssl_undefined_function,
    .ssl_connect = ssl23_connect,
    .ssl_read = ssl23_read,
    .ssl_peek = ssl23_peek,
    .ssl_write = ssl23_write,
    .ssl_shutdown = ssl_undefined_function,
    .ssl_get_message = ssl3_get_message,
    .ssl_read_bytes = ssl_recv_subproto,
    .ssl_write_bytes = ssl_write_bytes,
    .ssl_ctrl = ssl3_ctrl,
    .ssl_ctx_ctrl = ssl3_ctx_ctrl,
    .get_cipher_by_char = ssl3_get_cipher_by_char,
    .put_cipher_by_char = ssl3_put_cipher_by_char,
    .ssl_pending = ssl_undefined_const_function,
    .num_ciphers = ssl_num_ciphers,
    .get_cipher = ssl_get_cipher,
    .get_ssl_method = ssl23_get_method,
    .get_timeout = ssl23_default_timeout,
    .ssl3_enc = &ssl3_undef_enc_method,
    .ssl_version = ssl_undefined_void_function,
    .ssl_callback_ctrl = ssl3_callback_ctrl,
    .ssl_ctx_callback_ctrl = ssl3_ctx_callback_ctrl,
};

const SSL_METHOD SSLv3_client_method_data = {
    .version = SSL3_VERSION,
    .ssl_new = ssl3_new,
    .ssl_clear = ssl3_clear,
    .ssl_free = ssl_free,
    .ssl_accept = ssl_undefined_function,
    .ssl_connect = ssl3_connect,
    .ssl_read = ssl_read,
    .ssl_peek = ssl3_peek,
    .ssl_write = ssl_write,
    .ssl_shutdown = ssl_shutdown,
    .ssl_get_message = ssl3_get_message,
    .ssl_read_bytes = ssl_recv_subproto,
    .ssl_write_bytes = ssl_write_bytes,
    .ssl_ctrl = ssl3_ctrl,
    .ssl_ctx_ctrl = ssl3_ctx_ctrl,
    .get_cipher_by_char = ssl3_get_cipher_by_char,
    .put_cipher_by_char = ssl3_put_cipher_by_char,
    .ssl_pending = ssl_pending,
    .num_ciphers = ssl_num_ciphers,
    .get_cipher = ssl_get_cipher,
    .get_ssl_method = ssl3_get_client_method,
    .get_timeout = ssl3_default_timeout,
    .ssl3_enc = &SSLv3_enc_data,
    .ssl_version = ssl_undefined_void_function,
    .ssl_callback_ctrl = ssl3_callback_ctrl,
    .ssl_ctx_callback_ctrl = ssl3_ctx_callback_ctrl,
};

const SSL_METHOD SSLv3_method_data = {
    .version = SSL3_VERSION,
    .ssl_new = ssl3_new,
    .ssl_clear = ssl3_clear,
    .ssl_free = ssl_free,
    .ssl_accept = ssl_undefined_function,
    .ssl_connect = ssl3_connect,
    .ssl_read = ssl_read,
    .ssl_peek = ssl3_peek,
    .ssl_write = ssl_write,
    .ssl_shutdown = ssl_shutdown,
    .ssl_get_message = ssl3_get_message,
    .ssl_read_bytes = ssl_recv_subproto,
    .ssl_write_bytes = ssl_write_bytes,
    .ssl_ctrl = ssl3_ctrl,
    .ssl_ctx_ctrl = ssl3_ctx_ctrl,
    .get_cipher_by_char = ssl3_get_cipher_by_char,
    .put_cipher_by_char = ssl3_put_cipher_by_char,
    .ssl_pending = ssl_pending,
    .num_ciphers = ssl_num_ciphers,
    .get_cipher = ssl_get_cipher,
    .get_ssl_method = ssl3_get_method,
    .get_timeout = ssl3_default_timeout,
    .ssl3_enc = &SSLv3_enc_data,
    .ssl_version = ssl_undefined_void_function,
    .ssl_callback_ctrl = ssl3_callback_ctrl,
    .ssl_ctx_callback_ctrl = ssl3_ctx_callback_ctrl,
};

const SSL_METHOD TLSv1_method_data = {
    .version = TLS1_VERSION,
    .ssl_new = tls1_new,
    .ssl_clear = tls1_clear,
    .ssl_free = tls1_free,
    .ssl_accept = ssl_undefined_function,
    .ssl_connect = ssl3_connect,
    .ssl_read = ssl_read,
    .ssl_peek = ssl3_peek,
    .ssl_write = ssl_write,
    .ssl_shutdown = ssl_shutdown,
    .ssl_get_message = ssl3_get_message,
    .ssl_read_bytes = ssl_recv_subproto,
    .ssl_write_bytes = ssl_write_bytes,
    .ssl_ctrl = ssl3_ctrl,
    .ssl_ctx_ctrl = ssl3_ctx_ctrl,
    .get_cipher_by_char = ssl3_get_cipher_by_char,
    .put_cipher_by_char = ssl3_put_cipher_by_char,
    .ssl_pending = ssl_pending,
    .num_ciphers = ssl_num_ciphers,
    .get_cipher = ssl_get_cipher,
    .get_ssl_method = tls1_get_method,
    .get_timeout = tls1_default_timeout,
    .ssl3_enc = &TLSv1_enc_data,
    .ssl_version = ssl_undefined_void_function,
    .ssl_callback_ctrl = ssl3_callback_ctrl,
    .ssl_ctx_callback_ctrl = ssl3_ctx_callback_ctrl,
};

const SSL_METHOD TLSv1_1_method_data = {
    .version = TLS1_1_VERSION,
    .ssl_new = tls1_new,
    .ssl_clear = tls1_clear,
    .ssl_free = tls1_free,
    .ssl_accept = ssl_undefined_function,
    .ssl_connect = ssl3_connect,
    .ssl_read = ssl_read,
    .ssl_peek = ssl3_peek,
    .ssl_write = ssl_write,
    .ssl_shutdown = ssl_shutdown,
    .ssl_get_message = ssl3_get_message,
    .ssl_read_bytes = ssl_recv_subproto,
    .ssl_write_bytes = ssl_write_bytes,
    .ssl_ctrl = ssl3_ctrl,
    .ssl_ctx_ctrl = ssl3_ctx_ctrl,
    .get_cipher_by_char = ssl3_get_cipher_by_char,
    .put_cipher_by_char = ssl3_put_cipher_by_char,
    .ssl_pending = ssl_pending,
    .num_ciphers = ssl_num_ciphers,
    .get_cipher = ssl_get_cipher,
    .get_ssl_method = tls1_get_method,
    .get_timeout = tls1_default_timeout,
    .ssl3_enc = &TLSv1_1_enc_data,
    .ssl_version = ssl_undefined_void_function,
    .ssl_callback_ctrl = ssl3_callback_ctrl,
    .ssl_ctx_callback_ctrl = ssl3_ctx_callback_ctrl,
};

const SSL_METHOD TLSv1_2_method_data = {
    .version = TLS1_2_VERSION,
    .ssl_new = tls1_new,
    .ssl_clear = tls1_clear,
    .ssl_free = tls1_free,
    .ssl_accept = ssl_undefined_function,
    .ssl_connect = ssl3_connect,
    .ssl_read = ssl_read,
    .ssl_peek = ssl3_peek,
    .ssl_write = ssl_write,
    .ssl_shutdown = ssl_shutdown,
    .ssl_get_message = ssl3_get_message,
    .ssl_read_bytes = ssl_recv_subproto,
    .ssl_write_bytes = ssl_write_bytes,
    .ssl_ctrl = ssl3_ctrl,
    .ssl_ctx_ctrl = ssl3_ctx_ctrl,
    .get_cipher_by_char = ssl3_get_cipher_by_char,
    .put_cipher_by_char = ssl3_put_cipher_by_char,
    .ssl_pending = ssl_pending,
    .num_ciphers = ssl_num_ciphers,
    .get_cipher = ssl_get_cipher,
    .get_ssl_method = tls1_get_method,
    .get_timeout = tls1_default_timeout,
    .ssl3_enc = &TLSv1_2_enc_data,
    .ssl_version = ssl_undefined_void_function,
    .ssl_callback_ctrl = ssl3_callback_ctrl,
    .ssl_ctx_callback_ctrl = ssl3_ctx_callback_ctrl,
};

const SSL_METHOD TLSv1_client_method_data = {
    .version = TLS1_VERSION,
    .ssl_new = tls1_new,
    .ssl_clear = tls1_clear,
    .ssl_free = tls1_free,
    .ssl_accept = ssl_undefined_function,
    .ssl_connect = ssl3_connect,
    .ssl_read = ssl_read,
    .ssl_peek = ssl3_peek,
    .ssl_write = ssl_write,
    .ssl_shutdown = ssl_shutdown,
    .ssl_get_message = ssl3_get_message,
    .ssl_read_bytes = ssl_recv_subproto,
    .ssl_write_bytes = ssl_write_bytes,
    .ssl_ctrl = ssl3_ctrl,
    .ssl_ctx_ctrl = ssl3_ctx_ctrl,
    .get_cipher_by_char = ssl3_get_cipher_by_char,
    .put_cipher_by_char = ssl3_put_cipher_by_char,
    .ssl_pending = ssl_pending,
    .num_ciphers = ssl_num_ciphers,
    .get_cipher = ssl_get_cipher,
    .get_ssl_method = tls1_get_client_method,
    .get_timeout = tls1_default_timeout,
    .ssl3_enc = &TLSv1_enc_data,
    .ssl_version = ssl_undefined_void_function,
    .ssl_callback_ctrl = ssl3_callback_ctrl,
    .ssl_ctx_callback_ctrl = ssl3_ctx_callback_ctrl,
};

const SSL_METHOD TLSv1_1_client_method_data = {
    .version = TLS1_1_VERSION,
    .ssl_new = tls1_new,
    .ssl_clear = tls1_clear,
    .ssl_free = tls1_free,
    .ssl_accept = ssl_undefined_function,
    .ssl_connect = ssl3_connect,
    .ssl_read = ssl_read,
    .ssl_peek = ssl3_peek,
    .ssl_write = ssl_write,
    .ssl_shutdown = ssl_shutdown,
    .ssl_get_message = ssl3_get_message,
    .ssl_read_bytes = ssl_recv_subproto,
    .ssl_write_bytes = ssl_write_bytes,
    .ssl_ctrl = ssl3_ctrl,
    .ssl_ctx_ctrl = ssl3_ctx_ctrl,
    .get_cipher_by_char = ssl3_get_cipher_by_char,
    .put_cipher_by_char = ssl3_put_cipher_by_char,
    .ssl_pending = ssl_pending,
    .num_ciphers = ssl_num_ciphers,
    .get_cipher = ssl_get_cipher,
    .get_ssl_method = tls1_get_client_method,
    .get_timeout = tls1_default_timeout,
    .ssl3_enc = &TLSv1_1_enc_data,
    .ssl_version = ssl_undefined_void_function,
    .ssl_callback_ctrl = ssl3_callback_ctrl,
    .ssl_ctx_callback_ctrl = ssl3_ctx_callback_ctrl,
};

const SSL_METHOD TLSv1_2_client_method_data = {
    .version = TLS1_2_VERSION,
    .ssl_new = tls1_new,
    .ssl_clear = tls1_clear,
    .ssl_free = tls1_free,
    .ssl_accept = ssl_undefined_function,
    .ssl_connect = ssl3_connect,
    .ssl_read = ssl_read,
    .ssl_peek = ssl3_peek,
    .ssl_write = ssl_write,
    .ssl_shutdown = ssl_shutdown,
    .ssl_get_message = ssl3_get_message,
    .ssl_read_bytes = ssl_recv_subproto,
    .ssl_write_bytes = ssl_write_bytes,
    .ssl_ctrl = ssl3_ctrl,
    .ssl_ctx_ctrl = ssl3_ctx_ctrl,
    .get_cipher_by_char = ssl3_get_cipher_by_char,
    .put_cipher_by_char = ssl3_put_cipher_by_char,
    .ssl_pending = ssl_pending,
    .num_ciphers = ssl_num_ciphers,
    .get_cipher = ssl_get_cipher,
    .get_ssl_method = tls1_get_client_method,
    .get_timeout = tls1_default_timeout,
    .ssl3_enc = &TLSv1_2_enc_data,
    .ssl_version = ssl_undefined_void_function,
    .ssl_callback_ctrl = ssl3_callback_ctrl,
    .ssl_ctx_callback_ctrl = ssl3_ctx_callback_ctrl,
};

const SSL_METHOD *
TLSv1_client_method(void)
{
    return &TLSv1_client_method_data;
}

const SSL_METHOD *
TLSv1_1_client_method(void)
{
    return &TLSv1_1_client_method_data;
}

const SSL_METHOD *
TLSv1_2_client_method(void)
{
    return &TLSv1_2_client_method_data;
}

const SSL_METHOD *
TLSv1_method(void)
{
    return &TLSv1_method_data;
}

const SSL_METHOD *
TLSv1_1_method(void)
{
    return &TLSv1_1_method_data;
}

const SSL_METHOD *
TLSv1_2_method(void)
{
    return &TLSv1_2_method_data;
}

const SSL_METHOD *
SSLv3_method(void)
{
    return &SSLv3_method_data;
}

const SSL_METHOD *
SSLv3_client_method(void)
{
    return &SSLv3_client_method_data;
}
const SSL_METHOD *
SSLv23_client_method(void)
{
    return &SSLv23_client_method_data;
}

const SSL_METHOD *
SSLv23_method(void)
{
    return &SSLv23_method_data;
}


long
ssl23_default_timeout(void)
{
    return (300);
}

int
ssl23_read(SSL *s, void *buf, int len)
{
    int n;

    errno = 0;
    if (SSL_in_init(s) && (!s->in_handshake)) {
        n = s->handshake_func(s);
        if (n < 0)
            return (n);
        if (n == 0) {
            SSLerr(SSL_F_SSL23_READ, SSL_R_SSL_HANDSHAKE_FAILURE);
            return (-1);
        }
        return (SSL_read(s, buf, len));
    } else {
        ssl_undefined_function(s);
        return (-1);
    }
}

int
ssl23_peek(SSL *s, void *buf, int len)
{
    int n;

    errno = 0;
    if (SSL_in_init(s) && (!s->in_handshake)) {
        n = s->handshake_func(s);
        if (n < 0)
            return (n);
        if (n == 0) {
            SSLerr(SSL_F_SSL23_PEEK, SSL_R_SSL_HANDSHAKE_FAILURE);
            return (-1);
        }
        return (SSL_peek(s, buf, len));
    } else {
        ssl_undefined_function(s);
        return (-1);
    }
}

int
ssl23_write(SSL *s, const void *buf, int len)
{
    int n;

    errno = 0;
    if (SSL_in_init(s) && (!s->in_handshake)) {
        n = s->handshake_func(s);
        if (n < 0)
            return (n);
        if (n == 0) {
            SSLerr(SSL_F_SSL23_WRITE, SSL_R_SSL_HANDSHAKE_FAILURE);
            return (-1);
        }
        return (SSL_write(s, buf, len));
    } else {
        ssl_undefined_function(s);
        return (-1);
    }
}


int
ssl3_put_cipher_by_char(const SSL_CIPHER *c, unsigned char *p)
{
	if (p != NULL) {
		if ((c->id & ~SSL3_CK_VALUE_MASK) != SSL3_CK_ID)
			return (0);
		s2n(ssl_cipher_get_value(c), p); 
	}
	return (2);
}

int
ssl3_new(SSL *s)
{
	SSL3_STATE	*s3;

	if ((s3 = calloc(1, sizeof *s3)) == NULL)
		goto err;
	s->s3 = s3;

	s->method->ssl_clear(s);
	return (1);
err:
	return (0);
}

void
ssl3_clear(SSL *s)
{
	unsigned char	*rp, *wp;
	size_t		 rlen, wlen;
	int		 init_extra;

	ssl3_cleanup_key_block(s);
	if (s->s3->tmp.ca_names != NULL)
		sk_X509_NAME_pop_free(s->s3->tmp.ca_names, X509_NAME_free);

	DH_free(s->s3->tmp.dh);
	s->s3->tmp.dh = NULL;
	EC_KEY_free(s->s3->tmp.ecdh);
	s->s3->tmp.ecdh = NULL;

	rp = s->s3->rbuf.buf;
	wp = s->s3->wbuf.buf;
	rlen = s->s3->rbuf.len;
	wlen = s->s3->wbuf.len;
	init_extra = s->s3->init_extra;

	BIO_free(s->s3->handshake_buffer);
	s->s3->handshake_buffer = NULL;

	ssl3_free_digest_list(s);

	free(s->s3->alpn_selected);
	s->s3->alpn_selected = NULL;

	memset(s->s3, 0, sizeof *s->s3);
	s->s3->rbuf.buf = rp;
	s->s3->wbuf.buf = wp;
	s->s3->rbuf.len = rlen;
	s->s3->wbuf.len = wlen;
	s->s3->init_extra = init_extra;

	ssl_free_wbio_buffer(s);

	s->packet_length = 0;
	s->s3->in_read_app_data = 0;
	s->version = SSL3_VERSION;

	free(s->next_proto_negotiated);
	s->next_proto_negotiated = NULL;
	s->next_proto_negotiated_len = 0;
}


int
ssl_read(SSL *s, void *buf, int len)
{
	return ssl_read_internal(s, buf, len, 0);
}

int
ssl_write(SSL *s, const void *buf, int len)
{
	int	ret, n;

#if 0
	if (s->shutdown & SSL_SEND_SHUTDOWN) {
		s->rwstate = SSL_NOTHING;
		return (0);
	}
#endif
	errno = 0;

	/*
	 * This is an experimental flag that sends the
	 * last handshake message in the same packet as the first
	 * use data - used to see if it helps the TCP protocol during
	 * session-id reuse
	 */
	/* The second test is because the buffer may have been removed */
	if ((s->s3->flags & SSL3_FLAGS_POP_BUFFER) && (s->wbio == s->bbio)) {
		/* First time through, we write into the buffer */
		if (s->s3->delay_buf_pop_ret == 0) {
			ret = ssl_write_bytes(s, SSL3_RT_APPLICATION_DATA,
			    buf, len);
			if (ret <= 0)
				return (ret);

			s->s3->delay_buf_pop_ret = ret;
		}

		s->rwstate = SSL_WRITING;
		n = BIO_flush(s->wbio);
		if (n <= 0)
			return (n);
		s->rwstate = SSL_NOTHING;

		/* We have flushed the buffer, so remove it */
		ssl_free_wbio_buffer(s);
		s->s3->flags&= ~SSL3_FLAGS_POP_BUFFER;

		ret = s->s3->delay_buf_pop_ret;
		s->s3->delay_buf_pop_ret = 0;
	} else {
		ret = s->method->ssl_write_bytes(s, SSL3_RT_APPLICATION_DATA,
		    buf, len);
		if (ret <= 0)
			return (ret);
	}

	return (ret);
}

int
ssl_shutdown(SSL *s)
{
	int	ret;

	/*
	 * Don't do anything much if we have not done the handshake or
	 * we don't want to send messages :-)
	 */
	if ((s->quiet_shutdown) || (s->state == SSL_ST_BEFORE)) {
		s->shutdown = (SSL_SENT_SHUTDOWN|SSL_RECEIVED_SHUTDOWN);
		return (1);
	}

	if (!(s->shutdown & SSL_SENT_SHUTDOWN)) {
		s->shutdown|=SSL_SENT_SHUTDOWN;
		ssl_send_alert(s, SSL3_AL_WARNING, SSL_AD_CLOSE_NOTIFY);
		/*
		 * Our shutdown alert has been sent now, and if it still needs
	 	 * to be written, s->s3->alert_dispatch will be true
		 */
		if (s->s3->alert_dispatch)
			return(-1);	/* return WANT_WRITE */
	} else if (s->s3->alert_dispatch) {
		/* resend it if not sent */
		ret = ssl3_dispatch_alert(s);
		if (ret == -1) {
			/*
			 * We only get to return -1 here the 2nd/Nth
			 * invocation, we must  have already signalled
			 * return 0 upon a previous invoation,
			 * return WANT_WRITE
			 */
			return (ret);
		}
	} else if (!(s->shutdown & SSL_RECEIVED_SHUTDOWN)) {
		/* If we are waiting for a close from our peer, we are closed */
		s->method->ssl_read_bytes(s, 0, NULL, 0, 0);
		if (!(s->shutdown & SSL_RECEIVED_SHUTDOWN)) {
			return(-1);	/* return WANT_READ */
		}
	}

	if ((s->shutdown == (SSL_SENT_SHUTDOWN|SSL_RECEIVED_SHUTDOWN)) &&
	    !s->s3->alert_dispatch)
		return (1);
	else
		return (0);
}

int
ssl_read_internal(SSL *s, void *buf, int len, int peek)
{
	int	ret;

	errno = 0;
	s->s3->in_read_app_data = 1;
	ret = s->method->ssl_read_bytes(s,
	    SSL3_RT_APPLICATION_DATA, buf, len, peek);
	if ((ret == -1) && (s->s3->in_read_app_data == 2)) {
		/*
		 * ssl3_read_bytes decided to call s->handshake_func, which
		 * called ssl3_read_bytes to read handshake data.
		 * However, ssl3_read_bytes actually found application data
		 * and thinks that application data makes sense here; so disable
		 * handshake processing and try to read application data again.
		 */
		s->in_handshake++;
		ret = s->method->ssl_read_bytes(s,
		    SSL3_RT_APPLICATION_DATA, buf, len, peek);
		s->in_handshake--;
	} else
		s->s3->in_read_app_data = 0;

	return (ret);
}

int
ssl_pending(const SSL *s)
{
	if (s->rstate == SSL_ST_READ_BODY)
		return 0;

	return (s->s3->rrec.type == SSL3_RT_APPLICATION_DATA) ?
	    s->s3->rrec.length : 0;
}

int
ssl3_peek(SSL *s, void *buf, int len)
{
	return ssl_read_internal(s, buf, len, 1);
}

void
ssl_free(SSL *s)
{
	if (s == NULL)
		return;

	ssl3_cleanup_key_block(s);
	ssl_release_read_buffer(s);
	ssl_release_write_buffer(s);

	DH_free(s->s3->tmp.dh);
	EC_KEY_free(s->s3->tmp.ecdh);

	if (s->s3->tmp.ca_names != NULL)
		sk_X509_NAME_pop_free(s->s3->tmp.ca_names, X509_NAME_free);
	BIO_free(s->s3->handshake_buffer);
	ssl3_free_digest_list(s);
	free(s->s3->alpn_selected);

	OPENSSL_cleanse(s->s3, sizeof *s->s3);
	free(s->s3);
	s->s3 = NULL;
}

long
ssl3_default_timeout(void)
{
	/*
	 * 2 hours, the 24 hours mentioned in the SSLv3 spec
	 * is way too long for http, the cache would over fill
	 */
	return (60 * 60 * 2);
}

long
ssl3_ctx_ctrl(SSL_CTX *ctx, int cmd, long larg, void *parg)
{
	CERT	*cert;

	cert = ctx->cert;

	switch (cmd) {
	case SSL_CTRL_NEED_TMP_RSA:
		return (0);
	case SSL_CTRL_SET_TMP_RSA:
	case SSL_CTRL_SET_TMP_RSA_CB:
		SSLerr(SSL_F_SSL3_CTX_CTRL, ERR_R_SHOULD_NOT_HAVE_BEEN_CALLED);
		return (0);
	case SSL_CTRL_SET_TMP_DH:
		{
			DH *new = NULL, *dh;

			dh = (DH *)parg;
			if ((new = DHparams_dup(dh)) == NULL) {
				SSLerr(SSL_F_SSL3_CTX_CTRL,
				    ERR_R_DH_LIB);
				return 0;
			}
			if (!(ctx->options & SSL_OP_SINGLE_DH_USE)) {
				if (!DH_generate_key(new)) {
					SSLerr(SSL_F_SSL3_CTX_CTRL,
					    ERR_R_DH_LIB);
					DH_free(new);
					return 0;
				}
			}
			DH_free(cert->dh_tmp);
			cert->dh_tmp = new;
			return 1;
		}
		/*break; */

	case SSL_CTRL_SET_TMP_DH_CB:
		SSLerr(SSL_F_SSL3_CTX_CTRL, ERR_R_SHOULD_NOT_HAVE_BEEN_CALLED);
		return (0);

	case SSL_CTRL_SET_DH_AUTO:
		ctx->cert->dh_tmp_auto = larg;
		return (1);

	case SSL_CTRL_SET_TMP_ECDH:
		{
			EC_KEY *ecdh = NULL;

			if (parg == NULL) {
				SSLerr(SSL_F_SSL3_CTX_CTRL,
				    ERR_R_ECDH_LIB);
				return 0;
			}
			ecdh = EC_KEY_dup((EC_KEY *)parg);
			if (ecdh == NULL) {
				SSLerr(SSL_F_SSL3_CTX_CTRL,
				    ERR_R_EC_LIB);
				return 0;
			}
			if (!(ctx->options & SSL_OP_SINGLE_ECDH_USE)) {
				if (!EC_KEY_generate_key(ecdh)) {
					EC_KEY_free(ecdh);
					SSLerr(SSL_F_SSL3_CTX_CTRL,
					    ERR_R_ECDH_LIB);
					return 0;
				}
			}

			EC_KEY_free(cert->ecdh_tmp);
			cert->ecdh_tmp = ecdh;
			return 1;
		}
		/* break; */
	case SSL_CTRL_SET_TMP_ECDH_CB:
		{
			SSLerr(SSL_F_SSL3_CTX_CTRL,
			    ERR_R_SHOULD_NOT_HAVE_BEEN_CALLED);
			return (0);
		}
		break;
	case SSL_CTRL_SET_TLSEXT_SERVERNAME_ARG:
		ctx->tlsext_servername_arg = parg;
		break;
	case SSL_CTRL_SET_TLSEXT_TICKET_KEYS:
	case SSL_CTRL_GET_TLSEXT_TICKET_KEYS:
		{
			unsigned char *keys = parg;
			if (!keys)
				return 48;
			if (larg != 48) {
				SSLerr(SSL_F_SSL3_CTX_CTRL,
				    SSL_R_INVALID_TICKET_KEYS_LENGTH);
				return 0;
			}
			if (cmd == SSL_CTRL_SET_TLSEXT_TICKET_KEYS) {
				memcpy(ctx->tlsext_tick_key_name, keys, 16);
				memcpy(ctx->tlsext_tick_hmac_key,
				    keys + 16, 16);
				memcpy(ctx->tlsext_tick_aes_key, keys + 32, 16);
			} else {
				memcpy(keys, ctx->tlsext_tick_key_name, 16);
				memcpy(keys + 16,
				    ctx->tlsext_tick_hmac_key, 16);
				memcpy(keys + 32,
				    ctx->tlsext_tick_aes_key, 16);
			}
			return 1;
		}

	case SSL_CTRL_SET_TLSEXT_STATUS_REQ_CB_ARG:
		ctx->tlsext_status_arg = parg;
		return 1;
		break;

	case SSL_CTRL_SET_ECDH_AUTO:
		ctx->cert->ecdh_tmp_auto = larg;
		return 1;

		/* A Thawte special :-) */
	case SSL_CTRL_EXTRA_CHAIN_CERT:
		if (ctx->extra_certs == NULL) {
			if ((ctx->extra_certs = sk_X509_new_null()) == NULL)
				return (0);
		}
		sk_X509_push(ctx->extra_certs,(X509 *)parg);
		break;

	case SSL_CTRL_GET_EXTRA_CHAIN_CERTS:
		*(STACK_OF(X509) **)parg = ctx->extra_certs;
		break;

	case SSL_CTRL_CLEAR_EXTRA_CHAIN_CERTS:
		if (ctx->extra_certs) {
			sk_X509_pop_free(ctx->extra_certs, X509_free);
			ctx->extra_certs = NULL;
		}
		break;

	default:
		return (0);
	}
	return (1);
}

long
ssl3_ctx_callback_ctrl(SSL_CTX *ctx, int cmd, void (*fp)(void))
{
	CERT	*cert;

	cert = ctx->cert;

	switch (cmd) {
	case SSL_CTRL_SET_TMP_RSA_CB:
		SSLerr(SSL_F_SSL3_CTX_CTRL, ERR_R_SHOULD_NOT_HAVE_BEEN_CALLED);
		return (0);
	case SSL_CTRL_SET_TMP_DH_CB:
		cert->dh_tmp_cb = (DH *(*)(SSL *, int, int))fp;
		break;
	case SSL_CTRL_SET_TMP_ECDH_CB:
		cert->ecdh_tmp_cb = (EC_KEY *(*)(SSL *, int, int))fp;
		break;
	case SSL_CTRL_SET_TLSEXT_SERVERNAME_CB:
		ctx->tlsext_servername_callback =
		    (int (*)(SSL *, int *, void *))fp;
		break;

	case SSL_CTRL_SET_TLSEXT_STATUS_REQ_CB:
		ctx->tlsext_status_cb = (int (*)(SSL *, void *))fp;
		break;

	case SSL_CTRL_SET_TLSEXT_TICKET_KEY_CB:
		ctx->tlsext_ticket_key_cb = (int (*)(SSL *, unsigned char  *,
		    unsigned char *, EVP_CIPHER_CTX *, HMAC_CTX *, int))fp;
		break;

	default:
		return (0);
	}
	return (1);
}

long
ssl3_ctrl(SSL *s, int cmd, long larg, void *parg)
{
	int ret = 0;

	if (cmd == SSL_CTRL_SET_TMP_DH || cmd == SSL_CTRL_SET_TMP_DH_CB) {
		if (!ssl_cert_inst(&s->cert)) {
			SSLerr(SSL_F_SSL3_CTRL,
			    ERR_R_MALLOC_FAILURE);
			return (0);
		}
	}

	switch (cmd) {
	case SSL_CTRL_GET_SESSION_REUSED:
		ret = s->hit;
		break;
	case SSL_CTRL_GET_CLIENT_CERT_REQUEST:
		break;
	case SSL_CTRL_GET_NUM_RENEGOTIATIONS:
		ret = 0;
		break;
	case SSL_CTRL_CLEAR_NUM_RENEGOTIATIONS:
		ret = 0;
		break;
	case SSL_CTRL_GET_TOTAL_RENEGOTIATIONS:
		ret = 0;
		break;
	case SSL_CTRL_GET_FLAGS:
		ret = (int)(s->s3->flags);
		break;
	case SSL_CTRL_NEED_TMP_RSA:
		ret = 0;
		break;
	case SSL_CTRL_SET_TMP_RSA:
	case SSL_CTRL_SET_TMP_RSA_CB:
		SSLerr(SSL_F_SSL3_CTRL, ERR_R_SHOULD_NOT_HAVE_BEEN_CALLED);
		break;
	case SSL_CTRL_SET_TMP_DH:
		{
			DH *dh = (DH *)parg;
			if (dh == NULL) {
				SSLerr(SSL_F_SSL3_CTRL,
				    ERR_R_PASSED_NULL_PARAMETER);
				return (ret);
			}
			if ((dh = DHparams_dup(dh)) == NULL) {
				SSLerr(SSL_F_SSL3_CTRL,
				    ERR_R_DH_LIB);
				return (ret);
			}
			if (!(s->options & SSL_OP_SINGLE_DH_USE)) {
				if (!DH_generate_key(dh)) {
					DH_free(dh);
					SSLerr(SSL_F_SSL3_CTRL,
					    ERR_R_DH_LIB);
					return (ret);
				}
			}
			DH_free(s->cert->dh_tmp);
			s->cert->dh_tmp = dh;
			ret = 1;
		}
		break;

	case SSL_CTRL_SET_TMP_DH_CB:
		SSLerr(SSL_F_SSL3_CTRL, ERR_R_SHOULD_NOT_HAVE_BEEN_CALLED);
		return (ret);

	case SSL_CTRL_SET_DH_AUTO:
		s->cert->dh_tmp_auto = larg;
		return 1;

	case SSL_CTRL_SET_TMP_ECDH:
		{
			EC_KEY *ecdh = NULL;

			if (parg == NULL) {
				SSLerr(SSL_F_SSL3_CTRL,
				    ERR_R_PASSED_NULL_PARAMETER);
				return (ret);
			}
			if (!EC_KEY_up_ref((EC_KEY *)parg)) {
				SSLerr(SSL_F_SSL3_CTRL,
				    ERR_R_ECDH_LIB);
				return (ret);
			}
			ecdh = (EC_KEY *)parg;
			if (!(s->options & SSL_OP_SINGLE_ECDH_USE)) {
				if (!EC_KEY_generate_key(ecdh)) {
					EC_KEY_free(ecdh);
					SSLerr(SSL_F_SSL3_CTRL,
					    ERR_R_ECDH_LIB);
					return (ret);
				}
			}
			EC_KEY_free(s->cert->ecdh_tmp);
			s->cert->ecdh_tmp = ecdh;
			ret = 1;
		}
		break;
	case SSL_CTRL_SET_TMP_ECDH_CB:
		{
			SSLerr(SSL_F_SSL3_CTRL,
			    ERR_R_SHOULD_NOT_HAVE_BEEN_CALLED);
			return (ret);
		}
		break;
	case SSL_CTRL_SET_TLSEXT_HOSTNAME:
		if (larg == TLSEXT_NAMETYPE_host_name) {
			free(s->tlsext_hostname);
			s->tlsext_hostname = NULL;

			ret = 1;
			if (parg == NULL)
				break;
			if (strlen((char *)parg) > TLSEXT_MAXLEN_host_name) {
				SSLerr(SSL_F_SSL3_CTRL,
				    SSL_R_SSL3_EXT_INVALID_SERVERNAME);
				return 0;
			}
			if ((s->tlsext_hostname = strdup((char *)parg))
			    == NULL) {
				SSLerr(SSL_F_SSL3_CTRL,
				    ERR_R_INTERNAL_ERROR);
				return 0;
			}
		} else {
			SSLerr(SSL_F_SSL3_CTRL,
			    SSL_R_SSL3_EXT_INVALID_SERVERNAME_TYPE);
			return 0;
		}
		break;
	case SSL_CTRL_SET_TLSEXT_DEBUG_ARG:
		s->tlsext_debug_arg = parg;
		ret = 1;
		break;

	case SSL_CTRL_SET_TLSEXT_STATUS_REQ_TYPE:
		s->tlsext_status_type = larg;
		ret = 1;
		break;

	case SSL_CTRL_GET_TLSEXT_STATUS_REQ_EXTS:
		*(STACK_OF(X509_EXTENSION) **)parg = s->tlsext_ocsp_exts;
		ret = 1;
		break;

	case SSL_CTRL_SET_TLSEXT_STATUS_REQ_EXTS:
		s->tlsext_ocsp_exts = parg;
		ret = 1;
		break;

	case SSL_CTRL_GET_TLSEXT_STATUS_REQ_IDS:
		*(STACK_OF(OCSP_RESPID) **)parg = s->tlsext_ocsp_ids;
		ret = 1;
		break;

	case SSL_CTRL_SET_TLSEXT_STATUS_REQ_IDS:
		s->tlsext_ocsp_ids = parg;
		ret = 1;
		break;

	case SSL_CTRL_GET_TLSEXT_STATUS_REQ_OCSP_RESP:
		*(unsigned char **)parg = s->tlsext_ocsp_resp;
		return s->tlsext_ocsp_resplen;

	case SSL_CTRL_SET_TLSEXT_STATUS_REQ_OCSP_RESP:
		free(s->tlsext_ocsp_resp);
		s->tlsext_ocsp_resp = parg;
		s->tlsext_ocsp_resplen = larg;
		ret = 1;
		break;

	case SSL_CTRL_SET_ECDH_AUTO:
		s->cert->ecdh_tmp_auto = larg;
		ret = 1;
		break;

	default:
		break;
	}
	return (ret);
}

long
ssl3_callback_ctrl(SSL *s, int cmd, void (*fp)(void))
{
	int	ret = 0;

	if (cmd == SSL_CTRL_SET_TMP_DH_CB) {
		if (!ssl_cert_inst(&s->cert)) {
			SSLerr(SSL_F_SSL3_CALLBACK_CTRL,
			    ERR_R_MALLOC_FAILURE);
			return (0);
		}
	}

	switch (cmd) {
	case SSL_CTRL_SET_TMP_RSA_CB:
		SSLerr(SSL_F_SSL3_CTRL, ERR_R_SHOULD_NOT_HAVE_BEEN_CALLED);
		break;
	case SSL_CTRL_SET_TMP_DH_CB:
		s->cert->dh_tmp_cb = (DH *(*)(SSL *, int, int))fp;
		break;
	case SSL_CTRL_SET_TMP_ECDH_CB:
		s->cert->ecdh_tmp_cb = (EC_KEY *(*)(SSL *, int, int))fp;
		break;
	case SSL_CTRL_SET_TLSEXT_DEBUG_CB:
		s->tlsext_debug_cb = (void (*)(SSL *, int , int,
		    unsigned char *, int, void *))fp;
		break;
	default:
		break;
	}
	return (ret);
}


static int tls_decrypt_ticket(SSL *s, const unsigned char *tick, int ticklen,
    const unsigned char *sess_id, int sesslen,
    SSL_SESSION **psess);


long
tls1_default_timeout(void)
{
    /* 2 hours, the 24 hours mentioned in the TLSv1 spec
     * is way too long for http, the cache would over fill */
    return (60 * 60 * 2);
}

int
tls1_new(SSL *s)
{
    if (!ssl3_new(s))
        return (0);
    s->method->ssl_clear(s);
    return (1);
}

void
tls1_free(SSL *s)
{
    free(s->tlsext_session_ticket);
    ssl_free(s);
}

void
tls1_clear(SSL *s)
{
    ssl3_clear(s);
    s->version = s->method->version;
}


static int nid_list[] = {
    NID_sect163k1,      /* sect163k1 (1) */
    NID_sect163r1,      /* sect163r1 (2) */
    NID_sect163r2,      /* sect163r2 (3) */
    NID_sect193r1,      /* sect193r1 (4) */
    NID_sect193r2,      /* sect193r2 (5) */
    NID_sect233k1,      /* sect233k1 (6) */
    NID_sect233r1,      /* sect233r1 (7) */
    NID_sect239k1,      /* sect239k1 (8) */
    NID_sect283k1,      /* sect283k1 (9) */
    NID_sect283r1,      /* sect283r1 (10) */
    NID_sect409k1,      /* sect409k1 (11) */
    NID_sect409r1,      /* sect409r1 (12) */
    NID_sect571k1,      /* sect571k1 (13) */
    NID_sect571r1,      /* sect571r1 (14) */
    NID_secp160k1,      /* secp160k1 (15) */
    NID_secp160r1,      /* secp160r1 (16) */
    NID_secp160r2,      /* secp160r2 (17) */
    NID_secp192k1,      /* secp192k1 (18) */
    NID_X9_62_prime192v1,   /* secp192r1 (19) */
    NID_secp224k1,      /* secp224k1 (20) */
    NID_secp224r1,      /* secp224r1 (21) */
    NID_secp256k1,      /* secp256k1 (22) */
    NID_X9_62_prime256v1,   /* secp256r1 (23) */
    NID_secp384r1,      /* secp384r1 (24) */
    NID_secp521r1,      /* secp521r1 (25) */
    NID_brainpoolP256r1,    /* brainpoolP256r1 (26) */
    NID_brainpoolP384r1,    /* brainpoolP384r1 (27) */
    NID_brainpoolP512r1 /* brainpoolP512r1 (28) */
};

static const uint8_t ecformats_default[] = {
    TLSEXT_ECPOINTFORMAT_uncompressed,
    TLSEXT_ECPOINTFORMAT_ansiX962_compressed_prime,
    TLSEXT_ECPOINTFORMAT_ansiX962_compressed_char2
};

static const uint16_t eccurves_default[] = {
    14,         /* sect571r1 (14) */
    13,         /* sect571k1 (13) */
    25,         /* secp521r1 (25) */
    28,         /* brainpool512r1 (28) */
    11,         /* sect409k1 (11) */
    12,         /* sect409r1 (12) */
    27,         /* brainpoolP384r1 (27) */
    24,         /* secp384r1 (24) */
    9,          /* sect283k1 (9) */
    10,         /* sect283r1 (10) */
    26,         /* brainpoolP256r1 (26) */
    22,         /* secp256k1 (22) */
    23,         /* secp256r1 (23) */
    8,          /* sect239k1 (8) */
    6,          /* sect233k1 (6) */
    7,          /* sect233r1 (7) */
    20,         /* secp224k1 (20) */
    21,         /* secp224r1 (21) */
    4,          /* sect193r1 (4) */
    5,          /* sect193r2 (5) */
    18,         /* secp192k1 (18) */
    19,         /* secp192r1 (19) */
    1,          /* sect163k1 (1) */
    2,          /* sect163r1 (2) */
    3,          /* sect163r2 (3) */
    15,         /* secp160k1 (15) */
    16,         /* secp160r1 (16) */
    17,         /* secp160r2 (17) */
};

int
tls1_ec_curve_id2nid(uint16_t curve_id)
{
    /* ECC curves from draft-ietf-tls-ecc-12.txt (Oct. 17, 2005) */
    if ((curve_id < 1) ||
        ((unsigned int)curve_id > sizeof(nid_list) / sizeof(nid_list[0])))
        return 0;
    return nid_list[curve_id - 1];
}

uint16_t
tls1_ec_nid2curve_id(int nid)
{
    /* ECC curves from draft-ietf-tls-ecc-12.txt (Oct. 17, 2005) */
    switch (nid) {
    case NID_sect163k1: /* sect163k1 (1) */
        return 1;
    case NID_sect163r1: /* sect163r1 (2) */
        return 2;
    case NID_sect163r2: /* sect163r2 (3) */
        return 3;
    case NID_sect193r1: /* sect193r1 (4) */
        return 4;
    case NID_sect193r2: /* sect193r2 (5) */
        return 5;
    case NID_sect233k1: /* sect233k1 (6) */
        return 6;
    case NID_sect233r1: /* sect233r1 (7) */
        return 7;
    case NID_sect239k1: /* sect239k1 (8) */
        return 8;
    case NID_sect283k1: /* sect283k1 (9) */
        return 9;
    case NID_sect283r1: /* sect283r1 (10) */
        return 10;
    case NID_sect409k1: /* sect409k1 (11) */
        return 11;
    case NID_sect409r1: /* sect409r1 (12) */
        return 12;
    case NID_sect571k1: /* sect571k1 (13) */
        return 13;
    case NID_sect571r1: /* sect571r1 (14) */
        return 14;
    case NID_secp160k1: /* secp160k1 (15) */
        return 15;
    case NID_secp160r1: /* secp160r1 (16) */
        return 16;
    case NID_secp160r2: /* secp160r2 (17) */
        return 17;
    case NID_secp192k1: /* secp192k1 (18) */
        return 18;
    case NID_X9_62_prime192v1: /* secp192r1 (19) */
        return 19;
    case NID_secp224k1: /* secp224k1 (20) */
        return 20;
    case NID_secp224r1: /* secp224r1 (21) */
        return 21;
    case NID_secp256k1: /* secp256k1 (22) */
        return 22;
    case NID_X9_62_prime256v1: /* secp256r1 (23) */
        return 23;
    case NID_secp384r1: /* secp384r1 (24) */
        return 24;
    case NID_secp521r1: /* secp521r1 (25) */
        return 25;
    case NID_brainpoolP256r1: /* brainpoolP256r1 (26) */
        return 26;
    case NID_brainpoolP384r1: /* brainpoolP384r1 (27) */
        return 27;
    case NID_brainpoolP512r1: /* brainpoolP512r1 (28) */
        return 28;
    default:
        return 0;
    }
}

/*
 * Return the appropriate format list. If client_formats is non-zero, return
 * the client/session formats. Otherwise return the custom format list if one
 * exists, or the default formats if a custom list has not been specified.
 */
static void
tls1_get_formatlist(SSL *s, int client_formats, const uint8_t **pformats,
    size_t *pformatslen)
{
    if (client_formats != 0) {
        *pformats = s->session->tlsext_ecpointformatlist;
        *pformatslen = s->session->tlsext_ecpointformatlist_length;
        return;
    }

    *pformats = s->tlsext_ecpointformatlist;
    *pformatslen = s->tlsext_ecpointformatlist_length;
    if (*pformats == NULL) {
        *pformats = ecformats_default;
        *pformatslen = sizeof(ecformats_default);
    }
}

/*
 * Return the appropriate curve list. If client_curves is non-zero, return
 * the client/session curves. Otherwise return the custom curve list if one
 * exists, or the default curves if a custom list has not been specified.
 */
static void
tls1_get_curvelist(SSL *s, int client_curves, const uint16_t **pcurves,
    size_t *pcurveslen)
{
    if (client_curves != 0) {
        *pcurves = s->session->tlsext_ellipticcurvelist;
        *pcurveslen = s->session->tlsext_ellipticcurvelist_length;
        return;
    }

    *pcurves = s->tlsext_ellipticcurvelist;
    *pcurveslen = s->tlsext_ellipticcurvelist_length;
    if (*pcurves == NULL) {
        *pcurves = eccurves_default;
        *pcurveslen = sizeof(eccurves_default) / 2;
    }
}

/* Check that a curve is one of our preferences. */
int
tls1_check_curve(SSL *s, const unsigned char *p, size_t len)
{
    const uint16_t *curves;
    size_t curveslen, i;
    uint16_t cid;

    /* Only named curves are supported. */
    if (len != 3 || p[0] != NAMED_CURVE_TYPE)
        return (0);

    cid = (p[1] << 8) | p[2];

    tls1_get_curvelist(s, 0, &curves, &curveslen);

    for (i = 0; i < curveslen; i++) {
        if (curves[i] == cid)
            return (1);
    }
    return (0);
}

int
tls1_get_shared_curve(SSL *s)
{
    return NID_undef;
}

/* For an EC key set TLS ID and required compression based on parameters. */
static int
tls1_set_ec_id(uint16_t *curve_id, uint8_t *comp_id, EC_KEY *ec)
{
    const EC_GROUP *grp;
    const EC_METHOD *meth;
    int is_prime = 0;
    int nid, id;

    if (ec == NULL)
        return (0);

    /* Determine if it is a prime field. */
    if ((grp = EC_KEY_get0_group(ec)) == NULL)
        return (0);
    if ((meth = EC_GROUP_method_of(grp)) == NULL)
        return (0);
    if (EC_METHOD_get_field_type(meth) == NID_X9_62_prime_field)
        is_prime = 1;

    /* Determine curve ID. */
    nid = EC_GROUP_get_curve_name(grp);
    id = tls1_ec_nid2curve_id(nid);

    /* If we have an ID set it, otherwise set arbitrary explicit curve. */
    if (id != 0)
        *curve_id = id;
    else
        *curve_id = is_prime ? 0xff01 : 0xff02;

    /* Specify the compression identifier. */
    if (comp_id != NULL) {
        if (EC_KEY_get0_public_key(ec) == NULL)
            return (0);

        if (EC_KEY_get_conv_form(ec) == POINT_CONVERSION_COMPRESSED) {
            *comp_id = is_prime ?
                TLSEXT_ECPOINTFORMAT_ansiX962_compressed_prime :
                TLSEXT_ECPOINTFORMAT_ansiX962_compressed_char2;
        } else {
            *comp_id = TLSEXT_ECPOINTFORMAT_uncompressed;
        }
    }
    return (1);
}

/* Check that an EC key is compatible with extensions. */
static int
tls1_check_ec_key(SSL *s, const uint16_t *curve_id, const uint8_t *comp_id)
{
    size_t curveslen, formatslen, i;
    const uint16_t *curves;
    const uint8_t *formats;

    /*
     * Check point formats extension if present, otherwise everything
     * is supported (see RFC4492).
     */
    tls1_get_formatlist(s, 1, &formats, &formatslen);
    if (comp_id != NULL && formats != NULL) {
        for (i = 0; i < formatslen; i++) {
            if (formats[i] == *comp_id)
                break;
        }
        if (i == formatslen)
            return (0);
    }

    /*
     * Check curve list if present, otherwise everything is supported.
     */
    tls1_get_curvelist(s, 1, &curves, &curveslen);
    if (curve_id != NULL && curves != NULL) {
        for (i = 0; i < curveslen; i++) {
            if (curves[i] == *curve_id)
                break;
        }
        if (i == curveslen)
            return (0);
    }

    return (1);
}

/* Check EC server key is compatible with client extensions. */
int
tls1_check_ec_server_key(SSL *s)
{
    CERT_PKEY *cpk = s->cert->pkeys + SSL_PKEY_ECC;
    uint16_t curve_id;
    uint8_t comp_id;
    EVP_PKEY *pkey;
    int rv;

    if (cpk->x509 == NULL || cpk->privatekey == NULL)
        return (0);
    if ((pkey = X509_get_pubkey(cpk->x509)) == NULL)
        return (0);
    rv = tls1_set_ec_id(&curve_id, &comp_id, pkey->pkey.ec);
    EVP_PKEY_free(pkey);
    if (rv != 1)
        return (0);

    return tls1_check_ec_key(s, &curve_id, &comp_id);
}

/* Check EC temporary key is compatible with client extensions. */
int
tls1_check_ec_tmp_key(SSL *s)
{
    EC_KEY *ec = s->cert->ecdh_tmp;
    uint16_t curve_id;

    if (s->cert->ecdh_tmp_auto != 0) {
        /* Need a shared curve. */
        if (tls1_get_shared_curve(s) != NID_undef)
            return (1);
        return (0);
    }

    if (ec == NULL) {
        if (s->cert->ecdh_tmp_cb != NULL)
            return (1);
        return (0);
    }
    if (tls1_set_ec_id(&curve_id, NULL, ec) != 1)
        return (0);

    return tls1_check_ec_key(s, &curve_id, NULL);
}

/*
 * List of supported signature algorithms and hashes. Should make this
 * customisable at some point, for now include everything we support.
 */

static unsigned char tls12_sigalgs[] = {
    TLSEXT_hash_sha512, TLSEXT_signature_rsa,
    TLSEXT_hash_sha512, TLSEXT_signature_dsa,
    TLSEXT_hash_sha512, TLSEXT_signature_ecdsa,

    TLSEXT_hash_sha384, TLSEXT_signature_rsa,
    TLSEXT_hash_sha384, TLSEXT_signature_dsa,
    TLSEXT_hash_sha384, TLSEXT_signature_ecdsa,

    TLSEXT_hash_sha256, TLSEXT_signature_rsa,
    TLSEXT_hash_sha256, TLSEXT_signature_dsa,
    TLSEXT_hash_sha256, TLSEXT_signature_ecdsa,

    TLSEXT_hash_sha224, TLSEXT_signature_rsa,
    TLSEXT_hash_sha224, TLSEXT_signature_dsa,
    TLSEXT_hash_sha224, TLSEXT_signature_ecdsa,

    TLSEXT_hash_sha1, TLSEXT_signature_rsa,
    TLSEXT_hash_sha1, TLSEXT_signature_dsa,
    TLSEXT_hash_sha1, TLSEXT_signature_ecdsa,
};

int
tls12_get_req_sig_algs(SSL *s, unsigned char *p)
{
    size_t slen = sizeof(tls12_sigalgs);

    if (p)
        memcpy(p, tls12_sigalgs, slen);
    return (int)slen;
}

unsigned char *
ssl_add_clienthello_tlsext(SSL *s, unsigned char *p, unsigned char *limit)
{
    int extdatalen = 0;
    unsigned char *ret = p;
    int using_ecc = 0;

    /* See if we support any ECC ciphersuites. */
    if (s->version >= TLS1_VERSION) {
        STACK_OF(SSL_CIPHER) *cipher_stack = SSL_get_ciphers(s);
        unsigned long alg_k, alg_a;
        int i;

        for (i = 0; i < sk_SSL_CIPHER_num(cipher_stack); i++) {
            SSL_CIPHER *c = sk_SSL_CIPHER_value(cipher_stack, i);

            alg_k = c->algorithm_mkey;
            alg_a = c->algorithm_auth;

            if ((alg_k & (SSL_kECDHE|SSL_kECDHr|SSL_kECDHe) ||
                (alg_a & SSL_aECDSA))) {
                using_ecc = 1;
                break;
            }
        }
    }

    /* don't add extensions for SSLv3 unless doing secure renegotiation */
    if (s->client_version == SSL3_VERSION)
        return p;

    ret += 2;

    if (ret >= limit)
        return NULL; /* this really never occurs, but ... */

    if (s->tlsext_hostname != NULL) {
        /* Add TLS extension servername to the Client Hello message */
        size_t size_str, lenmax;

        /* check for enough space.
           4 for the servername type and extension length
           2 for servernamelist length
           1 for the hostname type
           2 for hostname length
           + hostname length
        */

        if ((size_t)(limit - ret) < 9)
            return NULL;

        lenmax = limit - ret - 9;
        if ((size_str = strlen(s->tlsext_hostname)) > lenmax)
            return NULL;

        /* extension type and length */
        s2n(TLSEXT_TYPE_server_name, ret);

        s2n(size_str + 5, ret);

        /* length of servername list */
        s2n(size_str + 3, ret);

        /* hostname type, length and hostname */
        *(ret++) = (unsigned char) TLSEXT_NAMETYPE_host_name;
        s2n(size_str, ret);
        memcpy(ret, s->tlsext_hostname, size_str);
        ret += size_str;
    }

    /*Add empty renegotiation info*/
    if ((size_t)(limit - ret) < 5) return NULL;
    s2n(TLSEXT_TYPE_renegotiate, ret);/*Set extension_type field*/
    s2n(1, ret);/*Set the length field*/
    *(ret++) = 0;

    if (using_ecc) {
        size_t curveslen, formatslen, lenmax;
        const uint16_t *curves;
        const uint8_t *formats;
        int i;

        /*
         * Add TLS extension ECPointFormats to the ClientHello message.
         */
        tls1_get_formatlist(s, 0, &formats, &formatslen);

        if ((size_t)(limit - ret) < 5)
            return NULL;

        lenmax = limit - ret - 5;
        if (formatslen > lenmax)
            return NULL;
        if (formatslen > 255) {
            SSLerr(SSL_F_SSL_ADD_CLIENTHELLO_TLSEXT,
                ERR_R_INTERNAL_ERROR);
            return NULL;
        }

        s2n(TLSEXT_TYPE_ec_point_formats, ret);
        s2n(formatslen + 1, ret);
        *(ret++) = (unsigned char)formatslen;
        memcpy(ret, formats, formatslen);
        ret += formatslen;

        /*
         * Add TLS extension EllipticCurves to the ClientHello message.
         */
        tls1_get_curvelist(s, 0, &curves, &curveslen);

        if ((size_t)(limit - ret) < 6)
            return NULL;

        lenmax = limit - ret - 6;
        if (curveslen > lenmax)
            return NULL;
        if (curveslen > 65532) {
            SSLerr(SSL_F_SSL_ADD_CLIENTHELLO_TLSEXT,
                ERR_R_INTERNAL_ERROR);
            return NULL;
        }

        s2n(TLSEXT_TYPE_elliptic_curves, ret);
        s2n((curveslen * 2) + 2, ret);

        /* NB: draft-ietf-tls-ecc-12.txt uses a one-byte prefix for
         * elliptic_curve_list, but the examples use two bytes.
         * http://www1.ietf.org/mail-archive/web/tls/current/msg00538.html
         * resolves this to two bytes.
         */
        s2n(curveslen * 2, ret);
        for (i = 0; i < curveslen; i++)
            s2n(curves[i], ret);
    }

    if (!(SSL_get_options(s) & SSL_OP_NO_TICKET)) {
        int ticklen;
        if (!s->new_session && s->session && s->session->tlsext_tick)
            ticklen = s->session->tlsext_ticklen;
        else if (s->session && s->tlsext_session_ticket &&
            s->tlsext_session_ticket->data) {
            ticklen = s->tlsext_session_ticket->length;
            s->session->tlsext_tick = malloc(ticklen);
            if (!s->session->tlsext_tick)
                return NULL;
            memcpy(s->session->tlsext_tick,
                s->tlsext_session_ticket->data, ticklen);
            s->session->tlsext_ticklen = ticklen;
        } else
            ticklen = 0;
        if (ticklen == 0 && s->tlsext_session_ticket &&
            s->tlsext_session_ticket->data == NULL)
            goto skip_ext;
        /* Check for enough room 2 for extension type, 2 for len
         * rest for ticket
         */
        if ((size_t)(limit - ret) < 4 + ticklen)
            return NULL;
        s2n(TLSEXT_TYPE_session_ticket, ret);

        s2n(ticklen, ret);
        if (ticklen) {
            memcpy(ret, s->session->tlsext_tick, ticklen);
            ret += ticklen;
        }
    }
skip_ext:

    if (TLS1_get_client_version(s) >= TLS1_2_VERSION) {
        if ((size_t)(limit - ret) < sizeof(tls12_sigalgs) + 6)
            return NULL;

        s2n(TLSEXT_TYPE_signature_algorithms, ret);
        s2n(sizeof(tls12_sigalgs) + 2, ret);
        s2n(sizeof(tls12_sigalgs), ret);
        memcpy(ret, tls12_sigalgs, sizeof(tls12_sigalgs));
        ret += sizeof(tls12_sigalgs);
    }

    if (s->tlsext_status_type == TLSEXT_STATUSTYPE_ocsp) {
        int i;
        long extlen, idlen, itmp;
        OCSP_RESPID *id;

        idlen = 0;
        for (i = 0; i < sk_OCSP_RESPID_num(s->tlsext_ocsp_ids); i++) {
            id = sk_OCSP_RESPID_value(s->tlsext_ocsp_ids, i);
            itmp = i2d_OCSP_RESPID(id, NULL);
            if (itmp <= 0)
                return NULL;
            idlen += itmp + 2;
        }

        if (s->tlsext_ocsp_exts) {
            extlen = i2d_X509_EXTENSIONS(s->tlsext_ocsp_exts, NULL);
            if (extlen < 0)
                return NULL;
        } else
            extlen = 0;

        if ((size_t)(limit - ret) < 7 + extlen + idlen)
            return NULL;
        s2n(TLSEXT_TYPE_status_request, ret);
        if (extlen + idlen > 0xFFF0)
            return NULL;
        s2n(extlen + idlen + 5, ret);
        *(ret++) = TLSEXT_STATUSTYPE_ocsp;
        s2n(idlen, ret);
        for (i = 0; i < sk_OCSP_RESPID_num(s->tlsext_ocsp_ids); i++) {
            /* save position of id len */
            unsigned char *q = ret;
            id = sk_OCSP_RESPID_value(s->tlsext_ocsp_ids, i);
            /* skip over id len */
            ret += 2;
            itmp = i2d_OCSP_RESPID(id, &ret);
            /* write id len */
            s2n(itmp, q);
        }
        s2n(extlen, ret);
        if (extlen > 0)
            i2d_X509_EXTENSIONS(s->tlsext_ocsp_exts, &ret);
    }

    if (s->ctx->next_proto_select_cb && !s->s3->tmp.finish_md_len) {
        /* The client advertises an emtpy extension to indicate its
         * support for Next Protocol Negotiation */
        if ((size_t)(limit - ret) < 4)
            return NULL;
        s2n(TLSEXT_TYPE_next_proto_neg, ret);
        s2n(0, ret);
    }

    if (s->alpn_client_proto_list != NULL &&
        s->s3->tmp.finish_md_len == 0) {
        if ((size_t)(limit - ret) < 6 + s->alpn_client_proto_list_len)
            return (NULL);
        s2n(TLSEXT_TYPE_application_layer_protocol_negotiation, ret);
        s2n(2 + s->alpn_client_proto_list_len, ret);
        s2n(s->alpn_client_proto_list_len, ret);
        memcpy(ret, s->alpn_client_proto_list,
            s->alpn_client_proto_list_len);
        ret += s->alpn_client_proto_list_len;
    }

    /*
     * Add padding to workaround bugs in F5 terminators.
     * See https://tools.ietf.org/html/draft-agl-tls-padding-03
     *
     * Note that this seems to trigger issues with IronPort SMTP
     * appliances.
     *
     * NB: because this code works out the length of all existing
     * extensions it MUST always appear last.
     */
    if (s->options & SSL_OP_TLSEXT_PADDING) {
        int hlen = ret - (unsigned char *)s->init_buf->data;

        /*
         * The code in s23_clnt.c to build ClientHello messages
         * includes the 5-byte record header in the buffer, while the
         * code in s3_clnt.c does not.
         */
        if (s->state == SSL23_ST_CW_CLNT_HELLO_A)
            hlen -= 5;
        if (hlen > 0xff && hlen < 0x200) {
            hlen = 0x200 - hlen;
            if (hlen >= 4)
                hlen -= 4;
            else
                hlen = 0;

            s2n(TLSEXT_TYPE_padding, ret);
            s2n(hlen, ret);
            memset(ret, 0, hlen);
            ret += hlen;
        }
    }

    if ((extdatalen = ret - p - 2) == 0)
        return p;

    s2n(extdatalen, p);
    return ret;
}


/*
 * tls1_alpn_handle_client_hello is called to process the ALPN extension in a
 * ClientHello.
 *   data: the contents of the extension, not including the type and length.
 *   data_len: the number of bytes in data.
 *   al: a pointer to the alert value to send in the event of a non-zero
 *       return.
 *   returns: 1 on success.
 */
static int
tls1_alpn_handle_client_hello(SSL *s, const unsigned char *data,
    unsigned int data_len, int *al)
{
    const unsigned char *selected;
    unsigned char selected_len;
    unsigned int proto_len;
    unsigned int i;
    int r;

    if (s->ctx->alpn_select_cb == NULL)
        return (1);

    if (data_len < 2)
        goto parse_error;

    /*
     * data should contain a uint16 length followed by a series of 8-bit,
     * length-prefixed strings.
     */
    i = ((unsigned int)data[0]) << 8 | ((unsigned int)data[1]);
    data_len -= 2;
    data += 2;
    if (data_len != i)
        goto parse_error;

    if (data_len < 2)
        goto parse_error;

    for (i = 0; i < data_len; ) {
        proto_len = data[i];
        i++;

        if (proto_len == 0)
            goto parse_error;

        if (i + proto_len < i || i + proto_len > data_len)
            goto parse_error;

        i += proto_len;
    }

    r = s->ctx->alpn_select_cb(s, &selected, &selected_len,
        data, data_len, s->ctx->alpn_select_cb_arg);
    if (r == SSL_TLSEXT_ERR_OK) {
        free(s->s3->alpn_selected);
        if ((s->s3->alpn_selected = malloc(selected_len)) == NULL) {
            *al = SSL_AD_INTERNAL_ERROR;
            return (-1);
        }
        memcpy(s->s3->alpn_selected, selected, selected_len);
        s->s3->alpn_selected_len = selected_len;
    }

    return (1);

parse_error:
    *al = SSL_AD_DECODE_ERROR;
    return (0);
}


/* ssl_next_proto_validate validates a Next Protocol Negotiation block. No
 * elements of zero length are allowed and the set of elements must exactly fill
 * the length of the block. */
static char
ssl_next_proto_validate(unsigned char *d, unsigned len)
{
    unsigned int off = 0;

    while (off < len) {
        if (d[off] == 0)
            return 0;
        off += d[off];
        off++;
    }

    return off == len;
}

int
ssl_parse_serverhello_tlsext(SSL *s, unsigned char **p, unsigned char *d,
    int n, int *al)
{
    unsigned short length;
    unsigned char *data = *p;
    int tlsext_servername = 0;

    s->s3->next_proto_neg_seen = 0;
    free(s->s3->alpn_selected);
    s->s3->alpn_selected = NULL;

    if (data >= (d + n - 2))
        return 1;

    n2s(data, length);
    if (data + length != d + n) {
        *al = SSL_AD_DECODE_ERROR;
        return 0;
    }

    while (data <= (d + n - 4)) {
        int type, size;
        n2s(data, type);
        n2s(data, size);

        if (data + size > (d + n))
            return 1;

        if (s->tlsext_debug_cb)
            s->tlsext_debug_cb(s, 1, type, data, size,
                s->tlsext_debug_arg);

        if (type == TLSEXT_TYPE_server_name) {
            if (s->tlsext_hostname == NULL || size > 0) {
                *al = TLS1_AD_UNRECOGNIZED_NAME;
                return 0;
            }
            tlsext_servername = 1;

        }
        else if (type == TLSEXT_TYPE_ec_point_formats) {
            unsigned char *sdata = data;
            size_t formatslen;
            uint8_t *formats;

            if (size < 1) {
                *al = TLS1_AD_DECODE_ERROR;
                return 0;
            }
            formatslen = *(sdata++);
            if (formatslen != size - 1) {
                *al = TLS1_AD_DECODE_ERROR;
                return 0;
            }

            if (!s->hit) {
                free(s->session->tlsext_ecpointformatlist);
                s->session->tlsext_ecpointformatlist = NULL;
                s->session->tlsext_ecpointformatlist_length = 0;

                if ((formats = reallocarray(NULL, formatslen,
                    sizeof(uint8_t))) == NULL) {
                    *al = TLS1_AD_INTERNAL_ERROR;
                    return 0;
                }
                memcpy(formats, sdata, formatslen);
                s->session->tlsext_ecpointformatlist = formats;
                s->session->tlsext_ecpointformatlist_length =
                    formatslen;
            }
        }
        else if (type == TLSEXT_TYPE_session_ticket) {
            if (s->tls_session_ticket_ext_cb &&
                !s->tls_session_ticket_ext_cb(s, data, size, s->tls_session_ticket_ext_cb_arg)) {
                *al = TLS1_AD_INTERNAL_ERROR;
                return 0;
            }
            if ((SSL_get_options(s) & SSL_OP_NO_TICKET) || (size > 0)) {
                *al = TLS1_AD_UNSUPPORTED_EXTENSION;
                return 0;
            }
            s->tlsext_ticket_expected = 1;
        }
        else if (type == TLSEXT_TYPE_status_request) {
            /* MUST be empty and only sent if we've requested
             * a status request message.
             */
            if ((s->tlsext_status_type == -1) || (size > 0)) {
                *al = TLS1_AD_UNSUPPORTED_EXTENSION;
                return 0;
            }
            /* Set flag to expect CertificateStatus message */
            s->tlsext_status_expected = 1;
        }
        else if (type == TLSEXT_TYPE_next_proto_neg &&
            s->s3->tmp.finish_md_len == 0) {
            unsigned char *selected;
            unsigned char selected_len;

            /* We must have requested it. */
            if (s->ctx->next_proto_select_cb == NULL) {
                *al = TLS1_AD_UNSUPPORTED_EXTENSION;
                return 0;
            }
            /* The data must be valid */
            if (!ssl_next_proto_validate(data, size)) {
                *al = TLS1_AD_DECODE_ERROR;
                return 0;
            }
            if (s->ctx->next_proto_select_cb(s, &selected, &selected_len, data, size, s->ctx->next_proto_select_cb_arg) != SSL_TLSEXT_ERR_OK) {
                *al = TLS1_AD_INTERNAL_ERROR;
                return 0;
            }
            s->next_proto_negotiated = malloc(selected_len);
            if (!s->next_proto_negotiated) {
                *al = TLS1_AD_INTERNAL_ERROR;
                return 0;
            }
            memcpy(s->next_proto_negotiated, selected, selected_len);
            s->next_proto_negotiated_len = selected_len;
            s->s3->next_proto_neg_seen = 1;
        }
        else if (type ==
            TLSEXT_TYPE_application_layer_protocol_negotiation) {
            unsigned int len;

            /* We must have requested it. */
            if (s->alpn_client_proto_list == NULL) {
                *al = TLS1_AD_UNSUPPORTED_EXTENSION;
                return 0;
            }
            if (size < 4) {
                *al = TLS1_AD_DECODE_ERROR;
                return (0);
            }

            /* The extension data consists of:
             *   uint16 list_length
             *   uint8 proto_length;
             *   uint8 proto[proto_length]; */
            len = ((unsigned int)data[0]) << 8 |
                ((unsigned int)data[1]);
            if (len != (unsigned int)size - 2) {
                *al = TLS1_AD_DECODE_ERROR;
                return (0);
            }
            len = data[2];
            if (len != (unsigned int)size - 3) {
                *al = TLS1_AD_DECODE_ERROR;
                return (0);
            }
            free(s->s3->alpn_selected);
            s->s3->alpn_selected = malloc(len);
            if (s->s3->alpn_selected == NULL) {
                *al = TLS1_AD_INTERNAL_ERROR;
                return (0);
            }
            memcpy(s->s3->alpn_selected, data + 3, len);
            s->s3->alpn_selected_len = len;

        } else if (type == TLSEXT_TYPE_renegotiate) {
            if (size!=1 || *data!=0)
            {
                SSLerr(SSL_F_SSL_PARSE_SERVERHELLO_TLSEXT,
                    SSL_R_RENEGOTIATION_MISMATCH);
                *al = SSL_AD_HANDSHAKE_FAILURE;
                return 0;
            }
        }
        data += size;
    }

    if (data != d + n) {
        *al = SSL_AD_DECODE_ERROR;
        return 0;
    }

    if (!s->hit && tlsext_servername == 1) {
        if (s->tlsext_hostname) {
            if (s->session->tlsext_hostname == NULL) {
                s->session->tlsext_hostname =
                    strdup(s->tlsext_hostname);

                if (!s->session->tlsext_hostname) {
                    *al = SSL_AD_UNRECOGNIZED_NAME;
                    return 0;
                }
            } else {
                *al = SSL_AD_DECODE_ERROR;
                return 0;
            }
        }
    }

    *p = data;

    return 1;
}

int
ssl_check_serverhello_tlsext(SSL *s)
{
    int ret = SSL_TLSEXT_ERR_NOACK;
    int al = SSL_AD_UNRECOGNIZED_NAME;

    /* If we are client and using an elliptic curve cryptography cipher
     * suite, then if server returns an EC point formats lists extension
     * it must contain uncompressed.
     */
    unsigned long alg_k = s->s3->tmp.new_cipher->algorithm_mkey;
    unsigned long alg_a = s->s3->tmp.new_cipher->algorithm_auth;
    if ((s->tlsext_ecpointformatlist != NULL) &&
        (s->tlsext_ecpointformatlist_length > 0) &&
        (s->session->tlsext_ecpointformatlist != NULL) &&
        (s->session->tlsext_ecpointformatlist_length > 0) &&
        ((alg_k & (SSL_kECDHE|SSL_kECDHr|SSL_kECDHe)) || (alg_a & SSL_aECDSA))) {
        /* we are using an ECC cipher */
        size_t i;
        unsigned char *list;
        int found_uncompressed = 0;
        list = s->session->tlsext_ecpointformatlist;
        for (i = 0; i < s->session->tlsext_ecpointformatlist_length; i++) {
            if (*(list++) == TLSEXT_ECPOINTFORMAT_uncompressed) {
                found_uncompressed = 1;
                break;
            }
        }
        if (!found_uncompressed) {
            SSLerr(SSL_F_SSL_CHECK_SERVERHELLO_TLSEXT, SSL_R_TLS_INVALID_ECPOINTFORMAT_LIST);
            return -1;
        }
    }
    ret = SSL_TLSEXT_ERR_OK;

    if (s->ctx != NULL && s->ctx->tlsext_servername_callback != 0)
        ret = s->ctx->tlsext_servername_callback(s, &al, s->ctx->tlsext_servername_arg);
    else if (s->initial_ctx != NULL && s->initial_ctx->tlsext_servername_callback != 0)
        ret = s->initial_ctx->tlsext_servername_callback(s, &al, s->initial_ctx->tlsext_servername_arg);

    /* If we've requested certificate status and we wont get one
     * tell the callback
     */
    if ((s->tlsext_status_type != -1) && !(s->tlsext_status_expected) &&
        s->ctx && s->ctx->tlsext_status_cb) {
        int r;
        /* Set resp to NULL, resplen to -1 so callback knows
         * there is no response.
         */
        free(s->tlsext_ocsp_resp);
        s->tlsext_ocsp_resp = NULL;
        s->tlsext_ocsp_resplen = -1;
        r = s->ctx->tlsext_status_cb(s, s->ctx->tlsext_status_arg);
        if (r == 0) {
            al = SSL_AD_BAD_CERTIFICATE_STATUS_RESPONSE;
            ret = SSL_TLSEXT_ERR_ALERT_FATAL;
        }
        if (r < 0) {
            al = SSL_AD_INTERNAL_ERROR;
            ret = SSL_TLSEXT_ERR_ALERT_FATAL;
        }
    }

    switch (ret) {
    case SSL_TLSEXT_ERR_ALERT_FATAL:
        ssl_send_alert(s, SSL3_AL_FATAL, al);

        return -1;
    case SSL_TLSEXT_ERR_ALERT_WARNING:
        ssl_send_alert(s, SSL3_AL_WARNING, al);

        return 1;
    case SSL_TLSEXT_ERR_NOACK:
        s->servername_done = 0;
    default:
        return 1;
    }
}

/* Since the server cache lookup is done early on in the processing of the
 * ClientHello, and other operations depend on the result, we need to handle
 * any TLS session ticket extension at the same time.
 *
 *   session_id: points at the session ID in the ClientHello. This code will
 *       read past the end of this in order to parse out the session ticket
 *       extension, if any.
 *   len: the length of the session ID.
 *   limit: a pointer to the first byte after the ClientHello.
 *   ret: (output) on return, if a ticket was decrypted, then this is set to
 *       point to the resulting session.
 *
 * If s->tls_session_secret_cb is set then we are expecting a pre-shared key
 * ciphersuite, in which case we have no use for session tickets and one will
 * never be decrypted, nor will s->tlsext_ticket_expected be set to 1.
 *
 * Returns:
 *   -1: fatal error, either from parsing or decrypting the ticket.
 *    0: no ticket was found (or was ignored, based on settings).
 *    1: a zero length extension was found, indicating that the client supports
 *       session tickets but doesn't currently have one to offer.
 *    2: either s->tls_session_secret_cb was set, or a ticket was offered but
 *       couldn't be decrypted because of a non-fatal error.
 *    3: a ticket was successfully decrypted and *ret was set.
 *
 * Side effects:
 *   Sets s->tlsext_ticket_expected to 1 if the server will have to issue
 *   a new session ticket to the client because the client indicated support
 *   (and s->tls_session_secret_cb is NULL) but the client either doesn't have
 *   a session ticket or we couldn't use the one it gave us, or if
 *   s->ctx->tlsext_ticket_key_cb asked to renew the client's ticket.
 *   Otherwise, s->tlsext_ticket_expected is set to 0.
 */
int
tls1_process_ticket(SSL *s, unsigned char *session_id, int len,
    const unsigned char *limit, SSL_SESSION **ret)
{
    /* Point after session ID in client hello */
    const unsigned char *p = session_id + len;
    unsigned short i;

    *ret = NULL;
    s->tlsext_ticket_expected = 0;

    /* If tickets disabled behave as if no ticket present
     * to permit stateful resumption.
     */
    if (SSL_get_options(s) & SSL_OP_NO_TICKET)
        return 0;
    if ((s->version <= SSL3_VERSION) || !limit)
        return 0;
    if (p >= limit)
        return -1;

    /* Skip past cipher list */
    n2s(p, i);
    p += i;
    if (p >= limit)
        return -1;
    /* Skip past compression algorithm list */
    i = *(p++);
    p += i;
    if (p > limit)
        return -1;
    /* Now at start of extensions */
    if ((p + 2) >= limit)
        return 0;
    n2s(p, i);
    while ((p + 4) <= limit) {
        unsigned short type, size;
        n2s(p, type);
        n2s(p, size);
        if (p + size > limit)
            return 0;
        if (type == TLSEXT_TYPE_session_ticket) {
            int r;
            if (size == 0) {
                /* The client will accept a ticket but doesn't
                 * currently have one. */
                s->tlsext_ticket_expected = 1;
                return 1;
            }
            if (s->tls_session_secret_cb) {
                /* Indicate that the ticket couldn't be
                 * decrypted rather than generating the session
                 * from ticket now, trigger abbreviated
                 * handshake based on external mechanism to
                 * calculate the master secret later. */
                return 2;
            }
            r = tls_decrypt_ticket(s, p, size, session_id, len, ret);
            switch (r) {
            case 2: /* ticket couldn't be decrypted */
                s->tlsext_ticket_expected = 1;
                return 2;
            case 3: /* ticket was decrypted */
                return r;
            case 4: /* ticket decrypted but need to renew */
                s->tlsext_ticket_expected = 1;
                return 3;
            default: /* fatal error */
                return -1;
            }
        }
        p += size;
    }
    return 0;
}

/* tls_decrypt_ticket attempts to decrypt a session ticket.
 *
 *   etick: points to the body of the session ticket extension.
 *   eticklen: the length of the session tickets extenion.
 *   sess_id: points at the session ID.
 *   sesslen: the length of the session ID.
 *   psess: (output) on return, if a ticket was decrypted, then this is set to
 *       point to the resulting session.
 *
 * Returns:
 *   -1: fatal error, either from parsing or decrypting the ticket.
 *    2: the ticket couldn't be decrypted.
 *    3: a ticket was successfully decrypted and *psess was set.
 *    4: same as 3, but the ticket needs to be renewed.
 */
static int
tls_decrypt_ticket(SSL *s, const unsigned char *etick, int eticklen,
    const unsigned char *sess_id, int sesslen, SSL_SESSION **psess)
{
    SSL_SESSION *sess;
    unsigned char *sdec;
    const unsigned char *p;
    int slen, mlen, renew_ticket = 0;
    unsigned char tick_hmac[EVP_MAX_MD_SIZE];
    HMAC_CTX hctx;
    EVP_CIPHER_CTX ctx;
    SSL_CTX *tctx = s->initial_ctx;
    /* Need at least keyname + iv + some encrypted data */
    if (eticklen < 48)
        return 2;
    /* Initialize session ticket encryption and HMAC contexts */
    HMAC_CTX_init(&hctx);
    EVP_CIPHER_CTX_init(&ctx);
    if (tctx->tlsext_ticket_key_cb) {
        unsigned char *nctick = (unsigned char *)etick;
        int rv = tctx->tlsext_ticket_key_cb(s, nctick, nctick + 16,
            &ctx, &hctx, 0);
        if (rv < 0) {
            EVP_CIPHER_CTX_cleanup(&ctx);
            return -1;
        }
        if (rv == 0) {
            EVP_CIPHER_CTX_cleanup(&ctx);
            return 2;
        }
        if (rv == 2)
            renew_ticket = 1;
    } else {
        /* Check key name matches */
        if (timingsafe_memcmp(etick, tctx->tlsext_tick_key_name, 16))
            return 2;
        HMAC_Init_ex(&hctx, tctx->tlsext_tick_hmac_key, 16,
            tlsext_tick_md(), NULL);
        EVP_DecryptInit_ex(&ctx, EVP_aes_128_cbc(), NULL,
            tctx->tlsext_tick_aes_key, etick + 16);
    }
    /* Attempt to process session ticket, first conduct sanity and
     * integrity checks on ticket.
     */
    mlen = HMAC_size(&hctx);
    if (mlen < 0) {
        EVP_CIPHER_CTX_cleanup(&ctx);
        return -1;
    }
    eticklen -= mlen;
    /* Check HMAC of encrypted ticket */
    HMAC_Update(&hctx, etick, eticklen);
    HMAC_Final(&hctx, tick_hmac, NULL);
    HMAC_CTX_cleanup(&hctx);
    if (timingsafe_memcmp(tick_hmac, etick + eticklen, mlen)) {
        EVP_CIPHER_CTX_cleanup(&ctx);
        return 2;
    }
    /* Attempt to decrypt session data */
    /* Move p after IV to start of encrypted ticket, update length */
    p = etick + 16 + EVP_CIPHER_CTX_iv_length(&ctx);
    eticklen -= 16 + EVP_CIPHER_CTX_iv_length(&ctx);
    sdec = malloc(eticklen);
    if (!sdec) {
        EVP_CIPHER_CTX_cleanup(&ctx);
        return -1;
    }
    EVP_DecryptUpdate(&ctx, sdec, &slen, p, eticklen);
    if (EVP_DecryptFinal(&ctx, sdec + slen, &mlen) <= 0) {
        free(sdec);
        EVP_CIPHER_CTX_cleanup(&ctx);
        return 2;
    }
    slen += mlen;
    EVP_CIPHER_CTX_cleanup(&ctx);
    p = sdec;

    sess = d2i_SSL_SESSION(NULL, &p, slen);
    free(sdec);
    if (sess) {
        /* The session ID, if non-empty, is used by some clients to
         * detect that the ticket has been accepted. So we copy it to
         * the session structure. If it is empty set length to zero
         * as required by standard.
         */
        if (sesslen)
            memcpy(sess->session_id, sess_id, sesslen);
        sess->session_id_length = sesslen;
        *psess = sess;
        if (renew_ticket)
            return 4;
        else
            return 3;
    }
    ERR_clear_error();
    /* For session parse failure, indicate that we need to send a new
     * ticket. */
    return 2;
}

/* Tables to translate from NIDs to TLS v1.2 ids */

typedef struct {
    int nid;
    int id;
} tls12_lookup;

static tls12_lookup tls12_md[] = {
    {NID_md5, TLSEXT_hash_md5},
    {NID_sha1, TLSEXT_hash_sha1},
    {NID_sha224, TLSEXT_hash_sha224},
    {NID_sha256, TLSEXT_hash_sha256},
    {NID_sha384, TLSEXT_hash_sha384},
    {NID_sha512, TLSEXT_hash_sha512},
    {NID_id_GostR3411_94, TLSEXT_hash_gost94},
    {NID_id_tc26_gost3411_2012_256, TLSEXT_hash_streebog_256},
    {NID_id_tc26_gost3411_2012_512, TLSEXT_hash_streebog_512}
};

static tls12_lookup tls12_sig[] = {
    {EVP_PKEY_RSA, TLSEXT_signature_rsa},
    {EVP_PKEY_DSA, TLSEXT_signature_dsa},
    {EVP_PKEY_EC, TLSEXT_signature_ecdsa},
    {EVP_PKEY_GOSTR01, TLSEXT_signature_gostr01},
};

static int
tls12_find_id(int nid, tls12_lookup *table, size_t tlen)
{
    size_t i;
    for (i = 0; i < tlen; i++) {
        if (table[i].nid == nid)
            return table[i].id;
    }
    return -1;
}

int
tls12_get_sigandhash(unsigned char *p, const EVP_PKEY *pk, const EVP_MD *md)
{
    int sig_id, md_id;
    if (!md)
        return 0;
    md_id = tls12_find_id(EVP_MD_type(md), tls12_md,
        sizeof(tls12_md) / sizeof(tls12_lookup));
    if (md_id == -1)
        return 0;
    sig_id = tls12_get_sigid(pk);
    if (sig_id == -1)
        return 0;
    p[0] = (unsigned char)md_id;
    p[1] = (unsigned char)sig_id;
    return 1;
}

int
tls12_get_sigid(const EVP_PKEY *pk)
{
    return tls12_find_id(pk->type, tls12_sig,
        sizeof(tls12_sig) / sizeof(tls12_lookup));
}

const EVP_MD *
tls12_get_hash(unsigned char hash_alg)
{
    switch (hash_alg) {
    case TLSEXT_hash_sha1:
        return EVP_sha1();
    case TLSEXT_hash_sha224:
        return EVP_sha224();
    case TLSEXT_hash_sha256:
        return EVP_sha256();
    case TLSEXT_hash_sha384:
        return EVP_sha384();
    case TLSEXT_hash_sha512:
        return EVP_sha512();
    default:
        return NULL;
    }
}

/* Set preferred digest for each key type */

int
tls1_process_sigalgs(SSL *s, const unsigned char *data, int dsize)
{
    int i, idx;
    const EVP_MD *md;
    CERT *c = s->cert;

    /* Extension ignored for inappropriate versions */
    if (!SSL_USE_SIGALGS(s))
        return 1;

    /* Should never happen */
    if (!c)
        return 0;

    c->pkeys[SSL_PKEY_DSA_SIGN].digest = NULL;
    c->pkeys[SSL_PKEY_RSA_SIGN].digest = NULL;
    c->pkeys[SSL_PKEY_RSA_ENC].digest = NULL;
    c->pkeys[SSL_PKEY_ECC].digest = NULL;
    c->pkeys[SSL_PKEY_GOST01].digest = NULL;

    for (i = 0; i < dsize; i += 2) {
        unsigned char hash_alg = data[i], sig_alg = data[i + 1];

        switch (sig_alg) {
        case TLSEXT_signature_rsa:
            idx = SSL_PKEY_RSA_SIGN;
            break;
        case TLSEXT_signature_dsa:
            idx = SSL_PKEY_DSA_SIGN;
            break;
        case TLSEXT_signature_ecdsa:
            idx = SSL_PKEY_ECC;
            break;
        case TLSEXT_signature_gostr01:
        case TLSEXT_signature_gostr12_256:
        case TLSEXT_signature_gostr12_512:
            idx = SSL_PKEY_GOST01;
            break;
        default:
            continue;
        }

        if (c->pkeys[idx].digest == NULL) {
            md = tls12_get_hash(hash_alg);
            if (md) {
                c->pkeys[idx].digest = md;
                if (idx == SSL_PKEY_RSA_SIGN)
                    c->pkeys[SSL_PKEY_RSA_ENC].digest = md;
            }
        }

    }

    /* Set any remaining keys to default values. NOTE: if alg is not
     * supported it stays as NULL.
     */
    if (!c->pkeys[SSL_PKEY_DSA_SIGN].digest)
        c->pkeys[SSL_PKEY_DSA_SIGN].digest = EVP_sha1();
    if (!c->pkeys[SSL_PKEY_RSA_SIGN].digest) {
        c->pkeys[SSL_PKEY_RSA_SIGN].digest = EVP_sha1();
        c->pkeys[SSL_PKEY_RSA_ENC].digest = EVP_sha1();
    }
    if (!c->pkeys[SSL_PKEY_ECC].digest)
        c->pkeys[SSL_PKEY_ECC].digest = EVP_sha1();
    return 1;
}
