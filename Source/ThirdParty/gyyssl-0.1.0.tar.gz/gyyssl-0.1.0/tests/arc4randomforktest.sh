#!/bin/sh
set -e
./arc4randomforktest
./arc4randomforktest -b
./arc4randomforktest -p
./arc4randomforktest -bp
